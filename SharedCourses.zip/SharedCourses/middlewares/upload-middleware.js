
// upload-middleware.js

const multer = require('multer');
const path = require('path');

// Se define el directorio donde se guardarán los archivos
const storage = multer.diskStorage({
    // Directorio donde se guardarán los archivos
    destination: path.join(__dirname, '../uploads'),
    filename: (request, file, callback) => {
        // Obtenemos la extensión del archivo original
        const fileExtension = path.extname(file.originalname);

        // Sufijo único del archivo
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);

        // Construimos el nombre del archivo concatenando el sufijo único con la extensión
        const newFileName = `${uniqueSuffix}${fileExtension}`;

        // Se llama al callback con el nombre del archivo
        callback(null, newFileName);
    }
});

const fileFilter = (req, file, callback) => {
    // Lista de extensiones permitidas
    const allowedExtensions = ['.png', '.jpg', '.jpeg'];
    const fileExtension = path.extname(file.originalname).toLowerCase();

    // Validar extensión
    if (!allowedExtensions.includes(fileExtension)) {
        return callback(new Error('Solo se permiten archivos PNG, JPG y JPEG'), false);
    }

    // Validar tipo MIME
    const allowedMimeTypes = ['image/png', 'image/jpeg'];
    if (!allowedMimeTypes.includes(file.mimetype)) {
        return callback(new Error('Solo se permiten archivos de tipo PNG o JPEG'), false);
    }

    // Permitir la carga
    callback(null, true);
};


// Filtro personalizado para verificar la extensión y el tipo MIME
const fileFilterOld = (req, file, callback) => {
    // Verificar la extensión del archivo
    const allowedExtensions = ['.png'];
    const fileExtension = path.extname(file.originalname).toLowerCase();
    if (!allowedExtensions.includes(fileExtension)) {
        return callback(new Error('Solo se permiten archivos con extensión .png'), false);
    }

    // Verificar el tipo MIME del archivo
    if (file.mimetype !== 'image/png') {
        return callback(new Error('Solo se permiten archivos de tipo PNG'), false);
    }

    // Permitir la carga si la extensión y el tipo MIME son válidos
    callback(null, true);
};

const upload = multer({
    storage: storage,
    fileFilter: fileFilter
});

module.exports = upload.single('file');
