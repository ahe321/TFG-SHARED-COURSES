
// usuarios.js
"use strict"

const express = require('express');
const router = express.Router();
const Controller = require('../business/controller');

const path = require('path');
const Usuario = require('../integration/usuario');
const Notificacion = require('../integration/notificacion');
const OrdenCompra = require('../integration/orden.js');
const Leccion = require('../integration/leccion.js')
const uploadMiddleware = require('../middlewares/upload-middleware');
const fs = require('fs');
const multer = require('multer');
require('dotenv').config();
const Stripe = require('stripe');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);


// Función para convertir el string 'DD/MM/YYYY' en una fecha UTC
function parseFechaUTC(fechaString) {
    // Dividir el string en día, mes y año
    const partes = fechaString.split('/');
    
    // Obtener día, mes y año de las partes del string
    const dia = parseInt(partes[0], 10);
    const mes = parseInt(partes[1], 10) - 1; // Restar 1 ya que los meses se indexan desde 0 en JavaScript
    const año = parseInt(partes[2], 10);
    
    // Crear una fecha en formato UTC
    const fechaUTC = new Date(Date.UTC(año, mes, dia));
    
    return fechaUTC;
}

router.get('/cursos', (request, response) => {
    const rol = request.session.usuario.administrador ? "administrador" : "usuario";
    response.status(200).render('cursos.ejs', { rol: rol });
});

router.get('/mis_cursos', (request, response) => {
    response.status(200).render('mis_cursos.ejs');
});

router.get('/profile', (request, response) => {
    response.status(200).render('profile.ejs');
});

router.get('/lista_amigos', (request, response) => {
    response.status(200).render('lista_amigos.ejs');
});

router.get('/lecciones', (request, response) => {
    response.status(200).render('lecciones.ejs');
});

router.get('/certificados', (req, res) => {
    const { nombreUsuario, apellido1, apellido2, nombreCurso, fecha } = req.query;

    // Si los parámetros no están presentes, puedes devolver un error o una página por defecto.
    if (!nombreUsuario || !nombreCurso || !fecha) {
        return res.status(400).send("Faltan parámetros");
    }

    // Renderizar la vista pasando los datos
    res.render('certificados.ejs', { userName: nombreUsuario, surname1: apellido1, surname2: apellido2, courseName: nombreCurso, completionDate: fecha });
});

router.get('/transacciones', (request, response) => {
    response.status(200).render('transacciones.ejs');
});

router.get('/foro', (request, response) => {
    response.status(200).render('foro.ejs');
});

router.get('/estadisticas', (request, response) => {
    response.status(200).render('estadisticas.ejs');
});

router.get('/crear_curso', (request, response) => {
    response.status(200).render('crear_curso.ejs');
});

router.post('/obtener-perfil', (request, response) => {
    // Verificamos que el usuario esté autenticado
    
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para obtener los datos del perfil.'
        });
    }
        

    const correoUsuario = request.session.usuario.correo;

    // Llamamos al controlador para obtener los datos del usuario
    Controller.getUsuarioByEmail(correoUsuario, (error, usuario) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener perfil',
                message: 'Hubo un problema al intentar obtener los datos del perfil. Por favor, inténtelo más tarde.'
            });
        }

        // Si el usuario se encuentra, respondemos con los datos del perfil
        return response.status(200).json({usuario});
    });
});

router.post('/cambiar-perfil', uploadMiddleware, (request, response) => {
    const correoUsuario = request.session.usuario.correo;

    // Llamamos al controlador para obtener los datos del usuario
    Controller.getUsuarioByEmail(correoUsuario, (error, usuario) => {
        if (error) {
            return response.status(500).json({
                title: 'Error',
                message: 'Hubo un problema al intentar actualizar los datos'
            });
        }

        // Solo actualizamos los datos si algo ha cambiado
        let updated = false;

        if (typeof request.file !== 'undefined') {
            usuario.foto = request.file;
            request.session.usuario.foto = usuario.foto;
            updated = true;
        }
        else
            usuario.foto = undefined;

        if (request.body.nombre && request.body.nombre !== usuario.nombre) {
            usuario.nombre = request.body.nombre;
            request.session.usuario.nombre = usuario.nombre;
            updated = true;
        }

        if (request.body.apellido1 && request.body.apellido1 !== usuario.apellido1) {
            usuario.apellido1 = request.body.apellido1;
            request.session.usuario.apellido1 = usuario.apellido1;
            updated = true;
        }

        if (request.body.apellido2 && request.body.apellido2 !== usuario.apellido2) {
            usuario.apellido2 = request.body.apellido2;
            request.session.usuario.apellido2 = usuario.apellido2;
            updated = true;
        }

        if (request.body.contrasena && request.body.contrasena !== usuario.contrasena) {
            usuario.contrasena = request.body.contrasena;
            request.session.usuario.contrasena = usuario.contrasena;
            updated = true;
        }

        if (request.body.preferencias && request.body.preferencias !== usuario.preferencias) {
            usuario.preferencias = request.body.preferencias;
            request.session.usuario.preferencias = usuario.preferencias;
            updated = true;
        }

        // Si hubo cambios, actualizamos el usuario
        if (updated) {
            Controller.actualizarUsuario(correoUsuario, usuario, (error) => {
                if (error) {
                    return response.status(500).json({
                        title: 'Error',
                        message: 'Hubo un problema al intentar actualizar los datos'
                    });
                }

                // Responda con éxito solo después de que se haya actualizado
                return response.status(200).json({
                    title: 'Éxito',
                    message: 'Datos actualizados correctamente'
                });
            });
        } else {
            // Si no hubo cambios, simplemente respondemos que no hubo cambios
            return response.status(400).json({
                title: 'Advertencia',
                message: 'No se han realizado cambios en los datos'
            });
        }
    });
});

router.get('/gestion-usuarios', (request, response) => {
    response.status(200).render('lista-usuarios.ejs');
});

router.post('/obtener-nuevos-usuarios', (request, response) => {
    Controller.getNuevosUsuarios((error, usuarios) => {
        if (error)
            response.status(500).json({
                title: "Problema técnico",
                message: 'No se ha podido cargar la página correctamente. Pruebe más adelante.' 
            });
        else
            response.status(200).json({ usuarios });
    })
});

router.post('/obtener-usuarios-validados', (request, response) => {
    Controller.getUsuariosValidos((error, usuarios) => {
        if (error)
            response.status(500).json({
                title: "Problema técnico",
                message: 'No se ha podido cargar la página correctamente. Pruebe más adelante.' 
            });
        else
            response.status(200).json({ usuarios });
    })
});

router.post('/aceptar-usuario', (request, response) => {
    const idUsuario = request.body.idUsuario;
    if (request.session.usuario.administraor == 0)
        response.status(404).json({
            title: "Permiso denegado",
            message: 'No dispone de los permisos para llevar a cabo la acción.' 
        });
    else 
        Controller.aceptarUsuario(idUsuario, (error) => {
            if (error)
                response.status(500).json({
                    title: "Problema técnico",
                    message: 'No se ha podido completar la acción. Pruebe más adelante.' 
                });
            else
            response.status(200).json({
                title: "Acción completada",
                message: 'Se ha aceptado la solicitud.' 
            });
        })
});

router.post('/rechazar-usuario', (request, response) => {
    const idUsuario = request.body.idUsuario;
    if (request.session.usuario.administraor == 0)
        response.status(404).json({
            title: "Permiso denegado",
            message: 'No dispone de los permisos para llevar a cabo la acción.' 
        });
    else 
        Controller.rechazarUsuario(idUsuario, (error) => {
            if (error)
                response.status(500).json({
                    title: "Problema técnico",
                    message: 'No se ha podido completar la acción. Pruebe más adelante.' 
                });
            else
                response.status(200).json({
                    title: "Acción completada",
                    message: 'Se ha rechazado la solicitud.' 
                });
        })
});

router.post('/nombrar-administrador', (request, response) => {
    const idUsuario = request.body.idUsuario;
    if (request.session.usuario.administraor == 0)
        response.status(404).json({
            title: "Permiso denegado",
            message: 'No dispone de los permisos para llevar a cabo la acción.' 
        });
    else 
        Controller.nombrarAdministrador(idUsuario, (error) => {
            if (error)
                response.status(500).json({
                    title: "Problema técnico",
                    message: 'No se ha podido completar la acción. Pruebe más adelante.' 
                });
            else
                response.status(200).json({
                    title: "Acción completada",
                    message: 'Se ha nombrado al usuario administrador.'
                });
        })
});

router.post('/obtener-amigos', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para obtener la lista de amigos.'
        });
    }

    const correoUsuario = request.session.usuario.correo;

    // Llamamos al controlador para obtener la lista de amigos del usuario
    Controller.getAmigosByEmail(correoUsuario, (error, amigos) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener amigos',
                message: 'Hubo un problema al intentar obtener la lista de amigos. Por favor, inténtelo más tarde.'
            });
        }

        // Si se obtienen los amigos correctamente, respondemos con la lista
        return response.status(200).json({ amigos });
    });
});

// usuarios.js
router.post('/agregar-amigo', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para agregar amigos.'
        });
    }

    const correoUsuario = request.session.usuario.correo;
    const correoAmigo = request.body.correoAmigo;

    if (correoAmigo === correoUsuario) {
        return response.status(400).json({
            title: 'Error',
            message: 'No pueded añadirte a ti mismo como amigo'
        });
    }

    if (!correoAmigo) {
        return response.status(400).json({
            title: 'Correo inválido',
            message: 'Formato no correcto.'
        });
    }

    // Llamamos al controlador para agregar el amigo
    Controller.agregarAmigo(correoUsuario, correoAmigo, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al agregar amigo',
                message: error.message || 'Hubo un problema al intentar agregar el amigo. Por favor, inténtelo más tarde.'
            });
        }

        return response.status(200).json({
            title: 'Amigo agregado',
            message: 'El amigo ha sido agregado correctamente.'
        });
    });
});

router.post('/eliminar-amigo', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para eliminar amigos.'
        });
    }

    const correoUsuario = request.session.usuario.correo;
    const correoAmigo = request.body.correoAmigo;

    // Llamamos al controlador para eliminar el amigo
    Controller.eliminarAmigo(correoUsuario, correoAmigo, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al eliminar amigo',
                message: 'Hubo un problema al intentar eliminar el amigo. Por favor, inténtelo más tarde.'
            });
        }

        return response.status(200).json({
            title: 'Amigo eliminado',
            message: 'El amigo ha sido eliminado correctamente.'
        });
    });
  
});

router.get('/obtener-cursos', (request, response) => {
    Controller.getCursos((error, cursos) => {
        if (error) {
            return response.status(500).json({
                title: "Problema técnico",
                message: "No se ha podido obtener la lista de cursos. Inténtelo más tarde."
            });
        }
        
        response.status(200).json({ cursos });
    });
});

// Ruta para obtener las notificaciones del usuario desde la sesión
router.get('/obtener-notificaciones', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para obtener las notificaciones.'
        });
    }

    const correoUsuario = request.session.usuario.correo;

    // Llamamos al controlador para obtener las notificaciones para el usuario
    Controller.getNotificacionesByEmail(correoUsuario, (error, notificaciones) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener notificaciones',
                message: 'Hubo un problema al intentar obtener las notificaciones. Por favor, inténtelo más tarde.'
            });
        }
        //console.log(notificaciones);
        // Si se obtienen las notificaciones correctamente, respondemos con ellas
        return response.status(200).json({ notificaciones });
    });
});

// Marcar mensaje como leído
router.post('/marcar-como-leida', (request, response) => {
    const mensajeId = request.body.id; // ID del mensaje a marcar como leído

    // Llamamos al controlador para marcar el mensaje como leído
    Controller.marcarComoLeida(mensajeId, (error) => {
        if (error) {
            return response.status(500).json({
                title: "Error al marcar como leído",
                message: 'Hubo un problema al intentar marcar el mensaje como leído.'
            });
        }

        return response.status(200).json({
            title: "Mensaje marcado",
            message: 'El mensaje ha sido marcado como leído.'
        });
    });
});

router.post('/eliminar-notificacion', (request, response) => {
    const idNotificacion = request.body.id;

    Controller.eliminarNotificacion(idNotificacion, (error) => {
        if (error) {
            response.status(500).json({
                title: "Problema técnico",
                message: 'No se ha podido eliminar la notificación. Pruebe más tarde.'
            });
        } else {
            response.status(200).json({
                title: "Notificación eliminada",
                message: 'La notificación ha sido eliminada con éxito.'
            });
        }
    });
});

// Ruta para enviar una notificación
router.post('/enviar-notificacion', (request, response) => {
    
    const { titulo, mensaje, correoUsuario, detalles } = request.body;

    // Creamos una nueva instancia de Notificacion
    const nuevaNotificacion = new Notificacion({
        titulo: titulo,
        mensaje: request.session.usuario.nombre + mensaje,
        correoUsuario: correoUsuario,
        detalles: detalles,
        leida: false // Al momento de crearla, la notificación está como no leída
    });

    // Aquí puedes integrar la lógica para almacenar la notificación, por ejemplo en una base de datos
    Controller.insertNotificacion(nuevaNotificacion, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Problema técnico',
                message: 'Hubo un problema al intentar enviar la notificación. Por favor, inténtelo más tarde.'
            });
        }
        
        // Si no hay error, respondemos con un mensaje de éxito
        return response.status(200).json({
            title: 'Notificación enviada',
            message: 'La notificación ha sido enviada correctamente.'
        });
    });
    
});



// Ruta para obtener las órdenes por correo
router.get('/ordenes-por-correo', (request, response) => {
    const correoUsuario = request.session.usuario.correo;
    
    Controller.getOrdenesByCorreo(correoUsuario, (error, ordenes) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener las órdenes',
                message: 'Hubo un problema al intentar obtener las órdenes. Por favor, inténtelo más tarde.'
            });
        }

        return response.status(200).json({ ordenes });
    });
});

// Ruta para crear una nueva orden y compartirla con amigos
/*
router.post('/crear-orden', (request, response) => {
    const { ordenData, correosAmigos } = request.body; // Recibimos la orden y los correos de los amigos
    ordenData.correo_usuario = request.session.usuario.correo;

    Controller.createOrden(ordenData, correosAmigos, (error, nuevaOrden) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al crear la orden',
                message: 'Hubo un problema al intentar crear la orden, hay una orden en curso o su amigo/usted posee el curso. Por favor, inténtelo más tarde.',
                error
            });
        }

        return response.status(200).json({ nuevaOrden });
    });
});
*/
router.post('/crear-orden', async (req, res) => {
    try {
        const { ordenData, correosAmigos } = req.body;
        ordenData.correo_usuario = req.session.usuario.correo;
        const usuarioCorreo = req.session.usuario.correo;

        const nombreCurso = ordenData.nombre_curso?.trim() || 'Curso en SharedCourses';
        const descripcionCurso = ordenData.descripcion?.trim() || 'Curso compartido con amigos';

        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            mode: 'payment',
            line_items: [
                {
                    price_data: {
                        currency: 'eur',
                        product_data: {
                            name: nombreCurso,
                            description: descripcionCurso,
                        },
                        unit_amount: Math.round(parseFloat(ordenData.precio_curso / (correosAmigos.length + 1)) * 100),
                    },
                    quantity: 1,
                }
            ],
            metadata: {
                usuario: usuarioCorreo,
                ordenData: JSON.stringify(ordenData),
                correosAmigos: JSON.stringify(correosAmigos)
            },
            // Redirigir siempre a la misma página
            success_url: `${process.env.FRONTEND_URL}/cursos?status=success`,
            cancel_url: `${process.env.FRONTEND_URL}/cursos`,
        });

        res.status(200).json({ checkoutUrl: session.url });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            title: 'Error de Stripe',
            message: 'Hubo un problema al generar la sesión de pago.'
        });
    }
});


const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET; // la verás en Stripe
/*
router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
    const sig = req.headers['stripe-signature'];

    let event;

    try {
        event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } catch (err) {
        console.log('Webhook signature error:', err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'checkout.session.completed') {
        const session = event.data.object;

        // Recuperar metadata
        const usuario = session.metadata.usuario;
        const ordenData = JSON.parse(session.metadata.ordenData);
        const correosAmigos = JSON.parse(session.metadata.correosAmigos);


        // Crear la orden en la DB
        Controller.createOrden(ordenData, correosAmigos, (error, nuevaOrden) => {
            if (error) {
                console.error('Error al crear orden desde webhook:', error);
            } else {
                console.log('Orden creada desde webhook:', nuevaOrden.id);
            }
        });
    }

    res.status(200).json({ received: true });
});
*/

router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
        event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } catch (err) {
        console.error('Webhook signature error:', err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    switch (event.type) {
        case 'checkout.session.completed':
            const session = event.data.object;
            if (session.metadata.idOrden) {
                // Caso: confirmar orden
                Controller.cambiarEstadoEnCola(session.metadata.idCurso, session.metadata.usuario, (err, orden) => {
                    if (err) console.error("Error cambiando estado:", err);
                    else console.log("Orden actualizada:", orden.id);
                });
            } else {
                // Caso: crear orden
                const usuario = session.metadata.usuario;
                const ordenData = JSON.parse(session.metadata.ordenData);
                const correosAmigos = JSON.parse(session.metadata.correosAmigos);
                Controller.createOrden(ordenData, correosAmigos, (err, nuevaOrden) => {
                    if (err) console.error("Error creando orden:", err);
                    else console.log("Orden creada:", nuevaOrden.id);
                });
            }
            break;

        default:
            console.log(`Evento no manejado: ${event.type}`);
    }

    res.json({ received: true });
});


// Ruta para cambiar el estado de la orden
/*
router.post('/cambiar-estado', (request, response) => {
    const curso = request.body.curso;
    const correo_usuario = request.session.usuario.correo;

    Controller.cambiarEstadoEnCola(curso.id, correo_usuario, (error, ordenActualizada) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al cambiar el estado',
                message: 'Hubo un problema al intentar cambiar el estado de la orden. Por favor, inténtelo más tarde.'
            });
        }

        return response.status(200).json({ ordenActualizada });
    });
});
*/
/*
// Ruta para cambiar el estado de la orden mediante pago de Stripe
router.post('/cambiar-estado', async (req, res) => {
    try {
        const curso = req.body.curso;
        const correo_usuario = req.session.usuario.correo;
        const orden = req.body.orden;

        // Preparar datos para Stripe
        const nombreCurso = curso.name?.trim() || 'Curso en SharedCourses';
        const descripcionCurso = curso.long_description?.trim() || 'Curso compartido con amigos';

        // Crear sesión de Stripe
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            mode: 'payment',
            line_items: [
                {
                    price_data: {
                        currency: 'eur',
                        product_data: {
                            name: nombreCurso,
                            description: descripcionCurso,
                        },
                        unit_amount: Math.round(parseFloat(orden.precio_dividido) * 100), // precio por amigo
                    },
                    quantity: 1,
                }
            ],
            metadata: {
                usuario: correo_usuario,
                idCurso: curso.id
            },
            success_url: `${process.env.FRONTEND_URL}/mis_cursos`,
            cancel_url: `${process.env.FRONTEND_URL}/mis_cursos`,
        });

        res.status(200).json({ checkoutUrl: session.url });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            title: 'Error de Stripe',
            message: 'Hubo un problema al generar la sesión de pago.'
        });
    }
});
*/
/*
router.post('/cambiar-estado', async (req, res) => {
    try {
        const curso = req.body.curso;
        const correo_usuario = req.session.usuario.correo;
        const orden = req.body.orden;

        // Primero cambiar el estado en la cola
        Controller.cambiarEstadoEnCola(curso.id, correo_usuario, async (error, ordenActualizada) => {
            if (error) {
                return res.status(500).json({
                    title: 'Error al cambiar el estado',
                    message: 'Hubo un problema al intentar cambiar el estado de la orden. Por favor, inténtelo más tarde.'
                });
            }

            // Preparar datos para Stripe
            const nombreCurso = curso.name?.trim() || 'Curso en SharedCourses';
            const descripcionCurso = curso.long_description?.trim() || 'Curso compartido con amigos';

            try {
                // Crear sesión de Stripe
                const session = await stripe.checkout.sessions.create({
                    payment_method_types: ['card'],
                    mode: 'payment',
                    line_items: [
                        {
                            price_data: {
                                currency: 'eur',
                                product_data: {
                                    name: nombreCurso,
                                    description: descripcionCurso,
                                },
                                unit_amount: Math.round(parseFloat(orden.precio_curso / orden.num_usuarios_d) * 100), // precio por amigo
                            },
                            quantity: 1,
                        }
                    ],
                    metadata: {
                        usuario: correo_usuario,
                        idCurso: curso.id
                    },
                    success_url: `${process.env.FRONTEND_URL}/mis_cursos`,
                    cancel_url: `${process.env.FRONTEND_URL}/mis_cursos`,
                });

                // Devolver checkoutUrl al frontend
                res.status(200).json({ checkoutUrl: session.url, ordenActualizada });

            } catch (stripeError) {
                console.error('Error al crear la sesión de Stripe:', stripeError);
                res.status(500).json({
                    title: 'Error de Stripe',
                    message: 'Hubo un problema al generar la sesión de pago.'
                });
            }
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            title: 'Error inesperado',
            message: 'Ha ocurrido un error al procesar la solicitud.'
        });
    }
});
*/

router.post('/cambiar-estado', async (req, res) => {
    try {
        const curso = req.body.curso;
        const correo_usuario = req.session.usuario.correo;
        const orden = req.body.orden;

        // Preparar datos para Stripe
        const nombreCurso = curso.name?.trim() || 'Curso en SharedCourses';
        const descripcionCurso = curso.long_description?.trim() || 'Curso compartido con amigos';

        // Crear sesión de Stripe
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            mode: 'payment',
            line_items: [
                {
                    price_data: {
                        currency: 'eur',
                        product_data: {
                            name: nombreCurso,
                            description: descripcionCurso,
                        },
                        unit_amount: Math.round(parseFloat(orden.precio_curso / orden.num_usuarios_d) * 100),
                    },
                    quantity: 1,
                }
            ],
            metadata: {
                usuario: correo_usuario,
                idCurso: curso.id,
                idOrden: orden.id // importante para saber cuál actualizar
            },
            success_url: `${process.env.FRONTEND_URL}/mis_cursos`,
            cancel_url: `${process.env.FRONTEND_URL}/mis_cursos`,
        });

        res.status(200).json({ checkoutUrl: session.url });

    } catch (error) {
        console.error('Error creando sesión de Stripe:', error);
        res.status(500).json({
            title: 'Error de Stripe',
            message: 'Hubo un problema al generar la sesión de pago.'
        });
    }
});




// Ruta para borrar una orden
router.delete('/borrar-orden', (request, response) => {
    const id_curso = request.body.id_curso;
    const correo_usuario = request.session.usuario.correo;

    Controller.deleteOrden(id_curso, correo_usuario, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al borrar la orden',
                message: 'Hubo un problema al intentar borrar la orden. Por favor, inténtelo más tarde.'
            });
        }

        return response.status(200).json({
            title: 'Orden eliminada',
            message: 'La orden ha sido eliminada con éxito.'
        });
    });
});


// Ruta para obtener todas las lecciones
router.get('/get-lecciones', (req, res) => {
    Controller.getLecciones((error, lecciones) => {
        if (error) {
            return res.status(500).json({ message: 'Error al obtener las lecciones', error });
        }
        return res.status(200).json(lecciones);
    });
});

// Ruta para obtener las lecciones completadas por un usuario
router.get('/get-lecciones-completadas', (req, res) => {
    const idUsuario = req.session.usuario.id; // Asumimos que el ID de usuario se pasa como query parameter

    if (!idUsuario) {
        return res.status(400).json({ message: 'Se requiere el idUsuario' });
    }

    Controller.getLeccionesCompletadas(idUsuario, (error, leccionesCompletadas) => {
        if (error) {
            return res.status(500).json({ message: 'Error al obtener las lecciones completadas', error });
        }
        
        // En caso de éxito, respondemos con las lecciones completadas
        return res.status(200).json(leccionesCompletadas);
    });
});

// Ruta para borrar una orden
router.post('/mark-lesson-completed', (request, response) => {
    const idUsuario = request.session.usuario.id;
    const idLeccion = request.body.idLeccion;
    const idCurso = request.body.idCurso;


    Controller.markLessonCompleted(idUsuario, idLeccion, idCurso, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al marcar la lección como completada',
                message: 'Hubo un problema al intentar marcar como completada la leccion. Por favor, inténtelo más tarde'
            });
        }

        return response.status(200).json({
            title: 'Leccion marcada como completada',
            message: 'La leccion se ha marcado como completada correctamente'
        });
    });
});

router.get('/get-certificados-usuario', (request, response) => {
    if (!request.session.usuario || !request.session.usuario.id) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para obtener sus certificados.'
        });
    }
    
    const idUsuario = request.session.usuario.id;
    const nombreUsuario = request.session.usuario.nombre;
    const apellido1 = request.session.usuario.apellido1;
    const apellido2 = request.session.usuario.apellido2;
    
    Controller.getCertificadosPorUsuario(idUsuario, (error, certificados) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener certificados',
                message: 'Hubo un problema al intentar obtener los certificados. Por favor, inténtelo más tarde.'
            });
        }
        
        return response.status(200).json({ certificados, nombreUsuario, apellido1, apellido2 });
    });
});

router.post('/insert-certificado', (request, response) => {
    if (!request.session.usuario || !request.session.usuario.id) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para agregar un certificado.'
        });
    }
    
    const { idCurso, nombreCurso, fechaEmision } = request.body;
    if (!idCurso || !nombreCurso || !fechaEmision) {
        return response.status(400).json({
            title: 'Datos insuficientes',
            message: 'Debe proporcionar todos los datos requeridos: idCurso, nombreCurso y fechaEmision.'
        });
    }
    
    const idUsuario = request.session.usuario.id;
    const fechaUTC = parseFechaUTC(fechaEmision);
    
    const nuevoCertificado = {
        idUsuario,
        idCurso,
        nombreCurso,
        fechaEmision: fechaUTC
    };

    console.log(nuevoCertificado);
    
    Controller.insertarCertificado(nuevoCertificado, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al insertar certificado',
                message: 'Hubo un problema al intentar agregar el certificado. Por favor, inténtelo más tarde.'
            });
        }
        
        return response.status(200).json({
            title: 'Certificado agregado',
            message: 'El certificado ha sido agregado exitosamente.'
        });
    });
});


router.post('/obtener-certificado', (request, response) => {
    if (!request.session.usuario || !request.session.usuario.id) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'El usuario debe estar autenticado para obtener el certificado.'
        });
    }
    
    const idUsuario = request.session.usuario.id;
    const idCurso = request.body.idCurso;
    
    Controller.obtenerCertificadoPorCursoYUsuario(idCurso, idUsuario, (error, certificado) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener el certificado',
                message: 'Hubo un problema al intentar obtener el certificado'
            });
        }
        return response.status(200).json({ certificado });
    });
});

// Ruta para obtener las preferencias del usuario
router.get('/get-preferencia', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(400).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para obtener las preferencias.'
        });
    }

    // Extraemos las preferencias del usuario desde la sesión
    const preferencias = request.session.usuario.preferencias;

    // Si no hay preferencias, respondemos con un mensaje adecuado
    if (!preferencias) {
        return response.status(404).json({
            title: 'Preferencias no encontradas',
            message: 'No se han encontrado preferencias asociadas a este usuario.'
        });
    }

    // Devolvemos las preferencias del usuario
    return response.status(200).json({ preferencias });
});


// Ruta para insertar un tema en el foro
router.post('/insertar-tema-foro', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para insertar un tema en el foro.'
        });
    }

    // Extraemos los datos del cuerpo de la solicitud
    const { idCurso, TituloTema, NombreUsuario, FotoUsuario } = request.body;

    // Verificamos que los datos necesarios estén presentes
    if (!idCurso || !TituloTema || !NombreUsuario || !FotoUsuario) {
        return response.status(400).json({
            title: 'Datos incompletos',
            message: 'Por favor, ingrese todos los campos: idTema, idCurso, TituloTema, NombreUsuario, FotoUsuario.'
        });
    }

    // Creamos el objeto del tema
    const temaForo = {
        idCurso: idCurso,
        TituloTema: TituloTema,
        NombreUsuario: request.session.usuario.nombre,
        FotoUsuario: request.session.usuario.foto,
    };

    console.log(temaForo);

    // Llamamos al controlador para insertar el tema en el foro
    Controller.insertarTemaForo(temaForo, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al insertar tema',
                message: 'Hubo un problema al intentar insertar el tema en el foro. Por favor, inténtelo más tarde.'
            });
        }

        // Si todo va bien, respondemos con un mensaje de éxito
        return response.status(200).json({
            title: 'Tema insertado',
            message: 'El tema ha sido insertado correctamente en el foro.'
        });
    });
});

// Definimos la ruta para obtener los temas del foro por idCurso
router.post('/leer-temas-foro', (req, res) => {
    const { idCurso } = req.body; // Obtenemos el idCurso del cuerpo de la solicitud

    // Verificamos que se haya proporcionado un idCurso
    if (!idCurso) {
        return res.status(400).json({
            title: 'Error',
            message: 'Se requiere un idCurso para obtener los temas del foro.'
        });
    }

    // Llamamos al controlador para obtener los temas del foro
    Controller.leerTemasForoPorIdCurso(idCurso, (error, temasForo) => {
        if (error) {
            return res.status(500).json({
                title: 'Error al leer los temas',
                message: 'Hubo un problema al intentar obtener los temas del foro.'
            });
        }

        // Si no se encontraron temas para el curso, respondemos adecuadamente
        if (!temasForo || temasForo.length === 0) {
            return res.status(404).json({
                title: 'Sin temas',
                message: 'No se encontraron temas para el curso proporcionado.'
            });
        }

        // Respondemos con los temas obtenidos
        return res.status(200).json({
            title: 'Temas encontrados',
            temasForo: temasForo
        });
    });
});

// Definimos la ruta para obtener los mensajes por idTema
router.post('/get-mensajes', (req, res) => {
    const { idTema } = req.body; // Obtenemos el idTema desde el cuerpo de la solicitud

    // Verificamos que se haya proporcionado un idTema
    if (!idTema) {
        return res.status(400).json({
            title: 'Error',
            message: 'Se requiere un idTema para obtener los mensajes del foro.'
        });
    }

    // Llamamos al controlador para obtener los mensajes del tema
    Controller.getMensajesPorIdTema(idTema, (error, mensajes) => {
        if (error) {
            return res.status(500).json({
                title: 'Error al leer los mensajes',
                message: 'Hubo un problema al intentar obtener los mensajes del tema.'
            });
        }

        // Si no se encontraron mensajes para el tema, respondemos adecuadamente
        if (!mensajes || mensajes.length === 0) {
            return res.status(404).json({
                title: 'Sin mensajes',
                message: 'No se encontraron mensajes para el tema proporcionado.'
            });
        }

        // Respondemos con los mensajes obtenidos
        return res.status(200).json({
            title: 'Mensajes encontrados',
            mensajes: mensajes
        });
    });
});



// Ruta para insertar un mensaje en un tema del foro
router.post('/insertar-mensaje-foro', (request, response) => {
    // Verificamos que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para insertar un mensaje en el foro.'
        });
    }

    // Extraemos los datos del cuerpo de la solicitud
    const { idTema, texto } = request.body;

    // Verificamos que los datos necesarios estén presentes
    if (!idTema || !texto) {
        return response.status(400).json({
            title: 'Datos incompletos',
            message: 'Por favor, ingrese todos los campos: idTema y texto.'
        });
    }

    // Creamos el objeto del mensaje
    const mensajeForo = {
        idTema: idTema,
        NombreUsuario: request.session.usuario.nombre,
        FotoUsuario: request.session.usuario.foto, 
        texto: texto
    };

    // Llamamos al controlador para insertar el mensaje en el foro
    Controller.insertarMensajeForo(mensajeForo, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al insertar mensaje',
                message: 'Hubo un problema al intentar insertar el mensaje en el foro. Por favor, inténtelo más tarde.'
            });
        }

        // Si todo va bien, respondemos con un mensaje de éxito
        return response.status(200).json({
            title: 'Mensaje insertado',
            message: 'El mensaje ha sido insertado correctamente en el foro.'
        });
    });
});


    // Ruta para insertar un rating
    router.post('/insertar-rating', (request, response) => {

        const idUsuario = request.session.usuario.id;
        const idCurso = request.body.idCurso;
        const rating = request.body.rating;

        // Validación básica de los datos
        if (!idUsuario || !idCurso || typeof rating !== 'number') {
            return response.status(400).json({
                title: 'Datos incompletos o inválidos',
                message: 'Se requiere idUsuario, idCurso y rating numérico.'
            });
        }

        // Llamar al controlador para insertar el rating
        Controller.insertRating(idUsuario, idCurso, rating, (error) => {
            if (error) {
                return response.status(500).json({
                    title: 'Error al insertar rating',
                    message: 'Ocurrió un error al guardar el rating.'
                });
            }

            return response.status(200).json({
                title: 'Rating insertado',
                message: 'El rating se insertó correctamente.'
            });
        });
    });


// Ruta para obtener el test asociado a una lección
router.post('/obtener-test-por-leccion', (request, response) => {
    const { idLeccion } = request.body;

    if (!idLeccion) {
        return response.status(400).json({
            title: 'ID de lección faltante',
            message: 'Debe proporcionar un ID de lección válido.'
        });
    }

    Controller.getTestsByIdLeccion(idLeccion, (error, test) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener el test',
                message: 'Hubo un problema al intentar obtener el test. Por favor, inténtelo más tarde.'
            });
        }
        return response.status(200).json({ test });
    });
});


router.get('/obtener-estadisticas', (request, response) => {
    // Llamamos al controlador para obtener las estadísticas generales de la plataforma
    Controller.getEstadisticas((error, estadisticas) => {
        if (error) {
            return response.status(500).json({
                title: 'Error al obtener estadísticas',
                message: 'Hubo un problema al intentar obtener las estadísticas. Por favor, inténtelo más tarde.'
            });
        }

        // Si se obtienen las estadísticas correctamente, respondemos con ellas
        return response.status(200).json({ estadisticas });
    });
});

// Configuración para guardar imágenes y videos en /public
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        if (file.fieldname === 'image') {
            cb(null, path.join(__dirname, '../public/img'));
        } else if (file.fieldname.includes('video')) {
            cb(null, path.join(__dirname, '../public/videos'));
        }
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage });

router.post(
    '/curso_crear',
    upload.any(), // para aceptar imagen + todos los videos
    (req, res) => {
        const { name, description, long_description, duration, level, type, precio } = req.body;

        // Buscar la imagen subida
        const imageFile = req.files.find(f => f.fieldname === 'image');
        const imagePath = `../public/img/${imageFile.filename}`;


        // Insertar curso
        Controller.crearCurso(
            { name, description, long_description, duration, level, type, precio, image: imagePath },
            req.files,
            req.body,
            (error) => {
                if (error) {
                    return res.status(500).json({
                        title: 'Error al crear curso',
                        message: error.message || 'Ocurrió un error al crear el curso.'
                    });
                }
                return res.status(200).json({
                    title: 'Curso creado',
                    message: 'El curso se creó correctamente.'
                });
            }
        );
    }
);

// Ruta para darse de baja
router.post('/darse-de-baja', (request, response) => {
    // Verificar que el usuario esté autenticado
    if (!request.session.usuario || !request.session.usuario.correo) {
        return response.status(401).json({
            title: 'No autenticado',
            message: 'Debe iniciar sesión para darse de baja.'
        });
    }

    const correoUsuario = request.session.usuario.correo;

    // Llamamos al controlador para eliminar/desactivar el usuario
    Controller.eliminarUsuario(correoUsuario, (error) => {
        if (error) {
            return response.status(500).json({
                title: 'Error',
                message: 'No se pudo procesar la baja del usuario. Inténtelo más tarde.'
            });
        }

        // Limpiar sesión del usuario
        request.session.destroy((err) => {
            if (err) {
                return response.status(500).json({
                    title: 'Error',
                    message: 'Se produjo un error al cerrar la sesión tras la baja.'
                });
            }

            return response.status(200).json({
                title: 'Baja completada',
                message: 'Su cuenta ha sido eliminada correctamente.'
            });
        });
    });
});


module.exports = router;