
// public.js
"use strict"

const express = require('express');
const router = express.Router();
const Controller = require('../business/controller');
const Usuario = require('../integration/usuario');

const path = require('path');
const uploadMiddleware = require('../middlewares/upload-middleware');

// Ruta de inicio. Se redirige a la página de principal
router.get('/', function (request, response) {
    response.status(200).render('home.ejs');
});

// Ruta de registro
router.get('/registro', (request, response) => {
    response.status(200).render('registro.ejs');
});

// Petición de creación de usuarios
router.post('/crear-usuario', uploadMiddleware, (request, response) => {
    // Obtención de los datos del cuerpo de la solicitud (assumimos que los datos están en el body)
    
    const usuario = new Usuario({
        id: null,
        correo: request.body.correo,
        contrasena: request.body.contrasena,
        nombre: request.body.nombre,
        apellido1: request.body.apellido1,
        apellido2: request.body.apellido2,
        foto: request.file,
        validado: false,
        administrador: false,
        activo: true
    });
    
    

    console.log(request.body)
    console.log(request.file)

    // Llama al método del controlador para crear el usuario
    
    Controller.createUsuario(usuario, (error) => {
        if (error) {
            response.status(500).json({ title: 'Problema técnico',
                    message: 'Se ha producido un error al crear el usuario. Pruebe más tarde.' });
        } else {
            response.status(201).json({ title: 'Registro completado', message: 'Su cuenta ha sido creada con éxito.' });
        }
    });
    
});

// Ruta para el login
router.get('/login', (request, response) => {
    response.status(200).render('login.ejs');
});

// Ruta de creación de sessión
router.post('/crear-sesionold', (request, response) => {
    const correo = request.body.correo;
    const contrasena = request.body.contrasena;

    Controller.isLoginCorrect(correo, contrasena, (error, usuario) => {
        console.log('Petición de login');
        if (error) {
            console.log('Error en el servidor');
            response.json({ title: 'Problema técnico', message: 'Se ha producido un error en el servidor. Pruebe más tarde.' });
        } else if (usuario === null) {
            console.log('Usuario no encontrado');
            response.status(530).json({ title: 'Login incorrecto', message: 'La contraseña no se corresponde con el usuario proporcionado.' });
        } else if (!usuario.activo) {
            console.log('Usuario inactivo');
            response.status(530).json({ title: 'Cuenta eliminada', message: 'Su cuenta ha sido eliminada.' });
        } else if (!usuario.validado) {
            console.log('Usuario no validado');
            response.status(530).json({ title: 'Cuenta no validada', message: 'Lamentablemente aún no ha sido validado por el administrador.' });
        } else {
            console.log('Usuario encontrado');
            request.session.usuario = usuario;
            
            if(usuario.administrador === null)
                response.status(200).json({ redirectUrl: '/cursos' });
            else
                response.status(200).json({ redirectUrl: '/gestion-usuarios' });
        }
    });
});

// Ruta de creación de sesión
router.post('/crear-sesion', (request, response) => {
    const correo = request.body.correo;
    const contrasena = request.body.contrasena;

    Controller.isLoginCorrect(correo, contrasena, (error, usuario) => {
        console.log('Petición de login');
        if (error) {
            console.log('Error en el servidor');
            return response.json({ title: 'Problema técnico', message: 'Se ha producido un error en el servidor. Pruebe más tarde.' });
        }
        if (usuario === null) {
            console.log('Usuario no encontrado');
            return response.status(530).json({ title: 'Login incorrecto', message: 'La contraseña no se corresponde con el usuario proporcionado.' });
        }
        if (!usuario.activo) {
            console.log('Usuario inactivo');
            return response.status(530).json({ title: 'Cuenta eliminada', message: 'Su cuenta ha sido eliminada.' });
        }
        if (!usuario.validado) {
            console.log('Usuario no validado');
            return response.status(530).json({ title: 'Cuenta no validada', message: 'Lamentablemente aún no ha sido validado por el administrador.' });
        }

        console.log('Usuario encontrado');
        request.session.usuario = usuario;

        // Obtener todas las órdenes del usuario
        Controller.getOrdenesByCorreo(correo, (errorOrdenes, ordenes) => {
            if (errorOrdenes) {
                console.log('Error obteniendo órdenes:', errorOrdenes.message);
                ordenes = [];
            }

            // Obtener certificados del usuario
            Controller.getCertificadosPorUsuario(usuario.id, (errorCertificados, certificados) => {
                if (errorCertificados) {
                    console.log('Error obteniendo certificados:', errorCertificados.message);
                    certificados = [];
                }

                // Obtener la lista de cursos
                Controller.getCursos((errorCursos, cursos) => {
                    if (errorCursos) {
                        console.log('Error obteniendo cursos:', errorCursos.message);
                        cursos = [];
                    }

                    // Filtrar órdenes con estado "comprado" y sin certificado
                    const cursosNoCertificados = ordenes
                        .filter(orden => 
                            orden.estado === 'comprado' && 
                            !certificados.some(cert => cert.idCurso === orden.id_curso)
                        )
                        .map(orden => {
                            const curso = cursos.find(c => c.id === orden.id_curso);
                            return curso ? { id: curso.id, nombre: curso.name } : null;
                        })
                        .filter(curso => curso !== null); // Eliminar los cursos no encontrados
                    //console.log(cursosNoCertificados);

                    const detallesAleatorios = [
                        "¡Es hora de continuar aprendiendo y completar este curso!",
                        "Recuerda, cada lección te acerca más a tu objetivo.",
                        "¡No te detengas ahora! El final está cerca.",
                        "Cada paso que das te acerca a dominar esta habilidad.",
                        "¡Sigue adelante, el conocimiento está a tu alcance!"
                    ];

                    // Seleccionamos un detalle aleatorio
                    const detalleAleatorio = detallesAleatorios[Math.floor(Math.random() * detallesAleatorios.length)];

                    // Si hay cursos sin certificar, enviar una notificación motivacional
                    if (cursosNoCertificados.length > 0) {
                        const cursoAleatorio = cursosNoCertificados[Math.floor(Math.random() * cursosNoCertificados.length)];
                        //console.log(cursoAleatorio);
                        const notificacion = {
                            titulo: "¡Sigue aprendiendo!",
                            mensaje: `No te detengas, estás a un paso de completar "${cursoAleatorio.nombre}". ¡Obtén tu certificado ahora!`,
                            correoUsuario: correo,
                            detalles: detalleAleatorio
                        };

                        Controller.insertNotificacion(notificacion, (errorNotificacion) => {
                            if (errorNotificacion) {
                                console.log('Error insertando notificación:', errorNotificacion.message);
                            }
                        });
                    }

                    // Redireccionar según el rol del usuario
                    const redirectUrl = usuario.administrador === null ? '/cursos' : '/gestion-usuarios';
                    response.status(200).json({ redirectUrl });
                });
            });
        });
    });
});



module.exports = router;