"use strict";

class UserRating {
    constructor(param = {}) {
        this.idUsuario = param.idUsuario || null;
        this.idCurso = param.idCurso || null;
        this.rating = param.rating || null; // Se espera un valor numérico de rating (por ejemplo, de 1 a 5)
    }

    static toString(object) {
        let string = 'UserRating {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new UserRating({
                idUsuario: row.idUsuario,
                idCurso: row.idCurso,
                rating: row.rating
            });
        });
    }
}

module.exports = UserRating;
