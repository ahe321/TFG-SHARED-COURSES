"use strict"

const pool = require('../integration/pool-container');
const DAOUtil = require('../integration/dao-utils');
const Notificacion = require('../integration/notificacion');

class DAONotificaciones {

    // Insertar una nueva notificación
    static insertNotificacion(notificacion, callback) {
        let query = "INSERT INTO `notificaciones` (`titulo`, `mensaje`, `correoUsuario`, `detalles`) VALUES (?, ?, ?, ?)";
        const interrogation = [notificacion.titulo, notificacion.mensaje, notificacion.correoUsuario, notificacion.detalles];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    // Leer todas las notificaciones de un usuario por correo
    static readNotificacionesByEmail(correo, callback) {
        let query = "SELECT * FROM `notificaciones` WHERE `correoUsuario` = ? ORDER BY `id` DESC";
        const interrogation = [correo];
        DAOUtil.read(pool, query, interrogation, Notificacion.transform, callback);
    }

    // Eliminar una notificación por su ID
    static deleteNotificacion(idNotificacion, callback) {
        let query = "DELETE FROM `notificaciones` WHERE `id` = ?";
        const interrogation = [idNotificacion];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    // Marcar una notificación como leída
    static marcarComoLeida(idNotificacion, callback) {
        let query = "UPDATE `notificaciones` SET `leida` = ? WHERE `id` = ?";
        const interrogation = [true, idNotificacion];  // Asumiendo que "true" marca como leída
        DAOUtil.write(pool, query, interrogation, callback);
    }


}

module.exports = DAONotificaciones;
