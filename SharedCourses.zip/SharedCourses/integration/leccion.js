"use strict"

class Leccion {

    constructor(param = {}) {
        this.id = param.id || null;
        this.idCurso = param.idCurso || null;
        this.nombre = param.nombre || null;
        this.ruta = param.ruta || null;
        this.question = param.question || null;
        this.option1 = param.option1 || null;
        this.option2 = param.option2 || null;
        this.option3 = param.option3 || null;
        this.correct = param.correct || null;
    }

    static toString(object) {
        let string = 'Leccion {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Leccion({
                id: row.id,
                idCurso: row.idCurso,
                nombre: row.nombre,
                ruta: row.ruta,
                question: row.question,
                option1: row.option1,
                option2: row.option2,
                option3: row.option3,
                correct: row.correct
            });
        });
    }
}

module.exports = Leccion;
