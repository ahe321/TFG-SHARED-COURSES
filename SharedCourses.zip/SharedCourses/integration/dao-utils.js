
// dao-utils.js
"use strict"

const sinConexionMessage = "Database Error: Sin conexión a la base de datos";
const operacionFallidaMessage = "Database Error: Operación fallida";
const objetoInvalidoMessage = "Database Error: Operación fallida";

class DAOUtil {
    
    static write(pool, query, interrogation, callback) {
        pool.getConnection(function(err, connection) {
            if (err) {
                callback(new Error(sinConexionMessage));
            } else {
                connection.query(query, interrogation, function(queryErr, rows) {
                    connection.release();
                    if (queryErr) {
                        callback(new Error(operacionFallidaMessage));
                    } else {
                        callback(null, rows);
                    }
                });
            }
        });
    }

    static read(pool, query, interrogation, transform, callback) {
        pool.getConnection(function(error, connection) {
            if (error)
                callback(new Error(sinConexionMessage), null)
            else {
                connection.query(query, interrogation, (error, rows) => {
                    connection.release();
                    if (error || rows === undefined)
                        callback(new Error(operacionFallidaMessage), null);
                    else if (Array.isArray(rows)) {
                        const instances = transform(rows);
                        callback(null, instances);
                    } else
                        callback(new Error(objetoInvalidoMessage), null);
                });
            }
        });
    }

    static one(error, array, callback) {
        if (error)
            callback(error, null);
        else if (array.length === 0)
            callback(null, null);
        else
            callback(null, array[0]);
    }

    static readOneAttribute(pool, query, interrogation, attribute, callback) {
        pool.getConnection(function(error, connection) {
            if (error)
                callback(new Error(sinConexionMessage), null)
            else {
                connection.query(query, interrogation, (error, rows) => {
                    connection.release();
                    if (error || rows === undefined)
                        callback(new Error(operacionFallidaMessage), null);
                    else if (Array.isArray(rows)) {
                        callback(null, rows[0][attribute]);
                    } else
                        callback(new Error(objetoInvalidoMessage), null);
                });
            }
        });
    }
}

module.exports = DAOUtil;