
// pool_container.js
"use strict"

const config = require('../config');
const mysqlConfig = config.mysqlConfig;
const mysql = require('mysql');
const pool = mysql.createPool({
  host: mysqlConfig.host,
  user: mysqlConfig.user,
  password: mysqlConfig.password,
  database: mysqlConfig.database
});

module.exports = pool;