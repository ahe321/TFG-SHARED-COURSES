"use strict";

class Estadisticas {

    constructor(param = {}) {
        this.id = param.id || null;
        this.cursosTotales = param.cursosTotales || 0;
        this.usuariosRegistrados = param.usuariosRegistrados || 0;
        this.valoracionPromedio = param.valoracionPromedio || 0.00;
        this.certificadosEmitidos = param.certificadosEmitidos || 0;
        this.fechaActualizacion = param.fechaActualizacion || null;
    }

    static toString(object) {
        let string = 'Estadisticas {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Estadisticas({
                id: row.id,
                cursosTotales: row.cursos_totales,
                usuariosRegistrados: row.usuarios_registrados,
                valoracionPromedio: row.valoracion_promedio,
                certificadosEmitidos: row.certificados_emitidos,
                fechaActualizacion: row.fecha_actualizacion
            });
        });
    }
}

module.exports = Estadisticas;
