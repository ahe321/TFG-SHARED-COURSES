"use strict"

const pool = require('../integration/pool-container');
// [ DEBUG ]
if (typeof pool === 'undefined') {
    console.log('ERROR: \'Valor indefinido\'');
    console.log('   Lugar: dao-cursos.js l.8');
    console.log('   Descripción: La variable pool no se ha inicializado correctamente');
}

const Curso = require('../integration/curso');
const DAOUtil = require('../integration/dao-utils');

class DAOCursos {

    static insertCurso(curso, callback) {
        const query = `
            INSERT INTO cursos (name, description, long_description, duration, level, image, type, precio)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const params = [curso.name, curso.description, curso.long_description, curso.duration, curso.level, curso.image, curso.type, curso.precio];

        pool.query(query, params, (err, result) => {
            if (err) return callback(err);
            callback(null, result.insertId);
        });
    }

    static readCursos(callback) {
        
        let query = "SELECT * FROM `cursos`;";
        const interrogation = [];
        DAOUtil.read(pool, query, interrogation, Curso.transform, callback);
        
    }
}

module.exports = DAOCursos;
