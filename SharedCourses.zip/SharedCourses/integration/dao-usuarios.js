
// dao-usuarios.js
"use strict"

const pool = require('../integration/pool-container');
// [ DEBUG ]
if (typeof pool === 'undefined') {
    console.log('ERROR: \'Valor indefinido\'');
    console.log('   Lugar: dao-usuarios.js l.8');
    console.log('   Decripción: La variable pool no se ha inicializado correctamente');
}

const Usuario = require('../integration/usuario');
const DAOUtil = require('../integration/dao-utils');

class DAOUsuarios {

    static insertUsuario(usuario, callback) {
        let query = "INSERT INTO `usuarios` (`correo`, `contrasena`, `nombre`, `apellido1`, `apellido2`, ";
        query += "`imagen`) VALUES (?, ?, ?, ?, ?, ?) ";
        const interrogation = [
            usuario.correo, usuario.contrasena, usuario.nombre, usuario.apellido1,
            usuario.apellido2, usuario.foto
        ];
        DAOUtil.write(pool, query, interrogation, callback);
    }
    
    static deleteUsuario(idUsuario, callback) {
        let query = "UPDATE `usuarios` SET `activo` = 0 WHERE `id` = ?;";
        const interrogation = [idUsuario];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    static validarUsuario(idUsuario, callback) {
        let query = "UPDATE `usuarios` SET `validado` = 1 WHERE `id` = ?;";
        const interrogation = [idUsuario];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    static nombrarAdministrador(idUsuario, callback) {
        let query = "UPDATE `usuarios` SET `administrador` = 1 WHERE `id` = ?;";
        const interrogation = [idUsuario];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    static readUsuarios(callback) {
        let query = "SELECT * FROM `usuarios` WHERE activo = 1;";
        const interrogation = [];
        DAOUtil.read(pool, query, interrogation, Usuario.transform, callback);
    }

    static readUsuarioById(idUsuario, callback) {
        this.readUsuariosById(idUsuario, (error, usuarios) => {
            DAOUtil.one(error, usuarios, callback);
        });
    }

    static readUsuariosById(idUsuario, callback) {
        let query = "SELECT * FROM ucm_aw_cau_usu_usuarios WHERE idUsuario = ? AND activo = 1;";
        const interrogation = [idUsuario];
        DAOUtil.read(pool, query, interrogation, Usuario.transform, callback);
    }

    static readUsuarioByEmail(email, callback) {
        this.readUsuariosByEmail(email, (error, usuarios) => {
            DAOUtil.one(error, usuarios, callback);
        });
    }

    static readUsuariosByEmail(email, callback) {
        let query = "SELECT * FROM usuarios WHERE correo = ?";
        const interrogation = [email];
        DAOUtil.read(pool, query, interrogation, Usuario.transform, callback);
    }

    static readUsuariosByValidation(validado, callback) {
        let query = "SELECT * FROM usuarios WHERE validado = ? AND activo = 1;";
        const interrogation = [validado];
        DAOUtil.read(pool, query, interrogation, Usuario.transform, callback);
    }

    static updateUsuario(correoUsuario, usuario, callback) {
        let query = "UPDATE `usuarios` SET `contrasena` = ?, `nombre` = ?, `apellido1` = ?, `apellido2` = ?, `imagen` = ?, `preferencias` = ? WHERE `correo` = ?;";
        const interrogation = [
            usuario.contrasena, usuario.nombre, usuario.apellido1,
            usuario.apellido2, usuario.foto, usuario.preferencias, correoUsuario
        ];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    static updateUsuarioSinFoto(correoUsuario, usuario, callback) {
        let query = "UPDATE `usuarios` SET `contrasena` = ?, `nombre` = ?, `apellido1` = ?, `apellido2` = ?, `preferencias` = ? WHERE `correo` = ?;";
        const interrogation = [
            usuario.contrasena, usuario.nombre, usuario.apellido1,
            usuario.apellido2, usuario.preferencias, correoUsuario
        ];
        DAOUtil.write(pool, query, interrogation, callback);
    }

     // Obtener la lista de amigos de un usuario por su correo electrónico
     static readAmigosByEmail(email, callback) {
        /*
        let query = `
            SELECT u.id, u.correo, u.nombre, u.apellido1, u.apellido2, u.imagen 
            FROM usuarios u
            JOIN amigos a ON (u.correo = a.email_amigo OR u.correo = a.email_usuario)
            WHERE (a.email_usuario = ? OR a.email_amigo = ?) AND u.correo != ?;
        `;
        */
        let query = `
            SELECT DISTINCT u.id, u.correo, u.nombre, u.apellido1, u.apellido2, u.imagen 
            FROM usuarios u
            JOIN amigos a ON (u.correo = a.email_amigo OR u.correo = a.email_usuario)
            WHERE (a.email_usuario = ? OR a.email_amigo = ?) AND u.correo != ?;
        `;


        const interrogation = [email, email, email];

        DAOUtil.read(pool, query, interrogation, Usuario.transform, (error, amigos) => {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, amigos);
        });
    }

    // dao-usuarios.js

static insertAmigosByEmail(correoUsuario, correoAmigo, callback) {
    // Consulta para insertar la relación de amistad
    let query = `
        INSERT INTO amigos (email_usuario, email_amigo)
        VALUES (?, ?), (?, ?);
    `;
    
    // Preparamos los correos de ambos usuarios para la relación de amistad bidireccional
    const interrogation = [correoUsuario, correoAmigo, correoAmigo, correoUsuario];

    // Ejecutamos la consulta
    DAOUtil.write(pool, query, interrogation, (error, results) => {
        if (error) {
            return callback(error);
        }

        callback(null); // Amistad insertada correctamente
    });
}

static deleteAmigoByEmail(correoUsuario, correoAmigo, callback) {
    // Consulta para eliminar la relación de amistad entre los dos usuarios
    let query = `
        DELETE FROM amigos 
        WHERE (email_usuario = ? AND email_amigo = ?) 
        OR (email_usuario = ? AND email_amigo = ?);
    `;

    // Preparar los correos de los dos usuarios para eliminar la relación de amistad bidireccional
    const interrogation = [correoUsuario, correoAmigo, correoAmigo, correoUsuario];
    
    // Ejecutar la consulta
    DAOUtil.write(pool, query, interrogation, (error, results) => {
        if (error) {
            return callback(error);  // En caso de error, lo retornamos
        }

        callback(null, results);  // Relación de amistad eliminada correctamente
    });
}

    static deleteUsuarioByEmail(correo, callback) {
        // Marcamos al usuario como inactivo en lugar de borrarlo físicamente
        let query = "UPDATE `usuarios` SET `activo` = 0 WHERE `correo` = ?;";
        const interrogation = [correo];
        DAOUtil.write(pool, query, interrogation, callback);
    }


}//fin dao

module.exports = DAOUsuarios;