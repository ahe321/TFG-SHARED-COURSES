"use strict"

class MensajesTema {

    constructor(param = {}) {
        this.idMensaje = param.idMensaje || null;
        this.idTema = param.idTema || null;
        this.NombreUsuario = param.NombreUsuario || null;
        this.FotoUsuario = param.FotoUsuario || null;
        this.texto = param.texto || null;
    }

    static toString(object) {
        let string = 'MensajesTema {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: `;
                if (key === 'fotoUsuario') {
                    string += '"No se puede mostrar una foto por texto",\n';
                } else {
                    string += `${object[key]},\n`;
                }
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new MensajesTema({
                idMensaje: row.idMensaje,
                idTema: row.idTema,
                NombreUsuario: row.NombreUsuario,
                FotoUsuario: row.FotoUsuario,
                texto: row.texto
            });
        });
    }
}

module.exports = MensajesTema;
