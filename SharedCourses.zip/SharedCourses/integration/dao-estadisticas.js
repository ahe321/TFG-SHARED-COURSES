"use strict"

const pool = require('../integration/pool-container');
// [ DEBUG ]
if (typeof pool === 'undefined') {
    console.log('ERROR: \'Valor indefinido\'');
    console.log('   Lugar: dao-estadisticas.js l.8');
    console.log('   Descripción: La variable pool no se ha inicializado correctamente');
}

const DAOUtil = require('../integration/dao-utils');
const Estadisticas = require('../integration/estadisticas.js');

class DAOEstadisticas {

    static obtenerEstadisticas(callback) {
        // Realizamos una consulta para obtener las estadísticas generales desde la tabla 'estadisticas_generales'
        let query = `
            SELECT 
                cursos_totales,
                usuarios_registrados,
                valoracion_promedio,
                certificados_emitidos
            FROM estadisticas_generales
            WHERE id = 1;  -- Solo obtenemos el registro con id = 1
        `;
        const interrogation = [];

        // Ejecutamos la consulta utilizando DAOUtil
        DAOUtil.read(pool, query, interrogation, Estadisticas.transform, callback);
    }
}

module.exports = DAOEstadisticas;
