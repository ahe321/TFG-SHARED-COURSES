"use strict"

const pool = require('../integration/pool-container');
const DAOUtil = require('../integration/dao-utils');

class DAORating {
    
    // Insertar rating de un usuario a un curso
    static insertRating(idUsuario, idCurso, rating, callback) {
        let query = `
            INSERT INTO user_rating (idUsuario, idCurso, rating)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE rating = VALUES(rating)
        `;
        const params = [idUsuario, idCurso, rating];

        DAOUtil.write(pool, query, params, (error, results) => {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, { success: true, message: "Rating insertado o actualizado correctamente" });
        });
    }
}

module.exports = DAORating;
