"use strict";

class UserLesson {
    constructor(param = {}) {
        this.idUsuario = param.idUsuario || null;
        this.idLeccion = param.idLeccion || null;
        this.idCurso = param.idCurso || null; 
        this.completada = param.completada || 0;  // 0 = No completada, 1 = Completada
    }

    static toString(object) {
        let string = 'UserLesson {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new UserLesson({
                idUsuario: row.idUsuario,
                idLeccion: row.idLeccion,
                idCurso: row.idCurso,  
                completada: row.completada
            });
        });
    }
}

module.exports = UserLesson;
