// dao-tests.js
"use strict";

const pool = require('../integration/pool-container');
const Test = require('../integration/tests');
const DAOUtil = require('../integration/dao-utils');

// [ DEBUG ]
if (typeof pool === 'undefined') {
    console.log('ERROR: \'Valor indefinido\'');
    console.log('   Lugar: dao-tests.js');
    console.log('   Descripción: La variable pool no se ha inicializado correctamente');
}

class DAOTests {

    static insertTest(test, callback) {
    const query = `
        INSERT INTO tests (idLeccion, question, option1, option2, option3, correct)
        VALUES (?, ?, ?, ?, ?, ?)
    `;
    const params = [test.idLeccion, test.question, test.option1, test.option2, test.option3, test.correct];
    pool.query(query, params, (err) => {
        if (err) return callback(err);
        callback(null);
    });
}

    // Obtener todos los tests asociados a una lección específica
    static readTestsByIdLeccion(idLeccion, callback) {
        const query = `
            SELECT * FROM tests
            WHERE idLeccion = ?;
        `;
        const interrogation = [idLeccion];
        DAOUtil.read(pool, query, interrogation, Test.transform, callback);
    }

}

module.exports = DAOTests;
