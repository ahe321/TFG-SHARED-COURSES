"use strict"

class Notificacion {

    constructor(param = {}) {
        this.id = param.id || null;
        this.titulo = param.titulo || null;
        this.mensaje = param.mensaje || null;
        this.correoUsuario = param.correoUsuario || null; // Correo del usuario asociado a la notificación
        this.detalles = param.detalles || null;
        this.leida = param.leida || null;
    }

    static toString(object) {
        let string = 'Notificacion {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Notificacion({
                id: row.id,
                titulo: row.titulo,
                mensaje: row.mensaje,
                correoUsuario: row.correoUsuario,
                detalles: row.detalles,
                leida: row.leida,
            });
        });
    }
}

module.exports = Notificacion;
