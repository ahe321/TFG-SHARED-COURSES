"use strict"

const pool = require('../integration/pool-container');
const DAOUtil = require('../integration/dao-utils');
const Certificado = require('../integration/certificado');

class DAOCertificados {

    static leerCertificadosPorIdUsuario(idUsuario, callback) {
        let query = "SELECT * FROM certificados WHERE idUsuario = ?";
        const interrogation = [idUsuario];
        DAOUtil.read(pool, query, interrogation, Certificado.transform, callback);
    }

    static insertarCertificado(certificado, callback) {
        let query = "INSERT INTO certificados (idUsuario, idCurso, nombreCurso, fechaEmision) VALUES (?, ?, ?, ?)";
        const interrogation = [
            certificado.idUsuario,
            certificado.idCurso,
            certificado.nombreCurso,
            certificado.fechaEmision || new Date().toISOString()
        ];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    static obtenerCertificadoPorCursoYUsuario(idCurso, idUsuario, callback) {
        let query = "SELECT * FROM certificados WHERE idCurso = ? AND idUsuario = ?";
        const interrogation = [idCurso, idUsuario];
        DAOUtil.read(pool, query, interrogation, Certificado.transform, callback);
    }
}

module.exports = DAOCertificados;
