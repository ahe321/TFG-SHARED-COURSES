"use strict"

class Curso {

    constructor(param = {}) {
        this.id = param.id || null;
        this.name = param.name || null;
        this.description = param.description || null;
        this.long_description = param.long_description || null;
        this.duration = param.duration || null;
        this.level = param.level || null;
        this.image = param.image || null;
        this.type = param.type || null;  
        this.precio = param.precio || null;
        this.rating = param.rating || null;
        this.num_rating = param.num_rating || null;
        this.sum_rating = param.sum_rating || null;
        this.num_inscritos = param.num_inscritos || null;
    }

    static toString(object) {
        let string = 'Curso {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: `;
                if (key === 'image') {
                    string += '"No se puede mostrar una imagen por texto",\n';
                } else {
                    string += `${object[key]},\n`;
                }
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Curso({
                id: row.id,
                name: row.name,
                description: row.description,
                long_description: row.long_description,
                duration: row.duration,
                level: row.level,
                image: row.image,
                type: row.type,
                precio: row.precio,
                rating: row.rating,
                num_rating: row.num_rating,
                sum_rating: row.sum_rating,
                num_inscritos: row.num_inscritos
            });
        });
    }
}

module.exports = Curso;
