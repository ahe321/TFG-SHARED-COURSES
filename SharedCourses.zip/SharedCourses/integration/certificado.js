"use strict";

class Certificado {
    constructor(param = {}) {
        this.idUsuario = param.idUsuario || null;
        this.idCurso = param.idCurso || null;
        this.nombreCurso = param.nombreCurso || null;
        this.fechaEmision = param.fechaEmision || new Date().toISOString();
    }

    static toString(object) {
        let string = 'Certificado {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Certificado({
                idUsuario: row.idUsuario,
                idCurso: row.idCurso,
                nombreCurso: row.nombreCurso,
                fechaEmision: row.fechaEmision
            });
        });
    }
}

module.exports = Certificado;
