
// usuario.js
"use strict"

class Usuario {

    constructor(param = {}) {
        this.id = param.id || null;
        this.correo = param.correo || null;
        this.contrasena = param.contrasena || null;
        this.nombre = param.nombre || null;
        this.apellido1 = param.apellido1 || null;
        this.apellido2 = param.apellido2 || null;
        this.foto = param.foto || null;
        this.validado = param.validado || null;
        this.administrador = param.administrador || null;
        this.activo = param.activo || null;
        this.preferencias = param.preferencias || "ninguna";
    }

    static toString(object) {
        let string = 'Usuario {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: `;
                if (key === 'foto') {
                    string += '"No se puede mostrar una foto por texto",\n';
                } else {
                    string += `${object[key]},\n`;
                }
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Usuario({
                id: row.id,
                correo: row.correo,
                contrasena: row.contrasena,
                nombre: row.nombre,
                apellido1: row.apellido1,
                apellido2: row.apellido2,
                foto: row.imagen,
                validado: !!row.validado,
                administrador: !!row.administrador,
                activo: !!row.activo,
                preferencias: row.preferencias || "ninguna"
            });
        });
    }
}

module.exports = Usuario;