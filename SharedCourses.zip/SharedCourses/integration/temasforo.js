"use strict"

class TemasForo {

    constructor(param = {}) {
        this.idTema = param.idTema || null;
        this.idCurso = param.idCurso || null;
        this.NombreUsuario = param.NombreUsuario || null;
        this.FotoUsuario = param.FotoUsuario || null;
        this.TituloTema = param.TituloTema || null;
    }

    static toString(object) {
        let string = 'TemasForo {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: `;
                if (key === 'fotoUsuario') {
                    string += '"No se puede mostrar una foto por texto",\n';
                } else {
                    string += `${object[key]},\n`;
                }
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new TemasForo({
                idTema: row.idTema,
                idCurso: row.idCurso,
                NombreUsuario: row.NombreUsuario,
                FotoUsuario: row.FotoUsuario,
                TituloTema: row.TituloTema
            });
        });
    }
}

module.exports = TemasForo;
