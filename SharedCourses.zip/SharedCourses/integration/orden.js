// orden.js
"use strict"

class OrdenCompra {

    constructor(param = {}) {
        this.id = param.id || null;
        this.id_curso = param.id_curso || null;
        this.correo_usuario = param.correo_usuario || null;
        this.num_usuarios_d = param.num_usuarios_d || 1;
        this.num_usuarios_c = param.num_usuarios_c || 1;
        this.precio_curso = param.precio_curso || 0;
        this.precio_dividido = param.precio_dividido || 0.00;
        this.estado = param.estado || 'sin_confirmar';
        this.fecha_emision = param.fecha_emision || new Date().toISOString();
        this.fecha_cobro = param.fecha_cobro || null;
    }

    static toString(object) {
        let string = 'OrdenCompra {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: `;
                if (key === 'estado') {
                    string += `"${object[key]}",\n`;
                } else {
                    string += `${object[key]},\n`;
                }
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new OrdenCompra({
                id: row.id,
                id_curso: row.id_curso,
                correo_usuario: row.correo_usuario,
                num_usuarios_d: row.num_usuarios_d,
                num_usuarios_c: row.num_usuarios_c,
                precio_curso: row.precio_curso,
                precio_dividido: row.precio_dividido,
                estado: row.estado,
                fecha_emision: row.fecha_emision,
                fecha_cobro: row.fecha_cobro
            });
        });
    }
}

module.exports = OrdenCompra;
