"use strict";

class Test {
    constructor(param = {}) {
        this.id = param.id || null;
        this.idLeccion = param.idLeccion || null;
        this.question = param.question || null;
        this.option1 = param.option1 || null;
        this.option2 = param.option2 || null;
        this.option3 = param.option3 || null;
        this.correct = param.correct || null; // Esperado: 1, 2 o 3
    }

    static toString(object) {
        let string = 'Test {\n';
        for (let key in object) {
            if (object[key] != null) {
                string += `\t ${key}: ${object[key]},\n`;
            }
        }
        string = string.slice(0, -2) + '\n}';
        return string;
    }

    static transform(rows) {
        return rows.map(row => {
            return new Test({
                id: row.id,
                idLeccion: row.idLeccion,
                question: row.question,
                option1: row.option1,
                option2: row.option2,
                option3: row.option3,
                correct: row.correct
            });
        });
    }
}

module.exports = Test;
