"use strict"

const pool = require('../integration/pool-container');
const MensajesTema = require('../integration/mensajestema');
const DAOUtil = require('../integration/dao-utils');

class DAOMensajesTema {

    // Leer los mensajes de un tema específico por su ID
    static leerMensajesPorIdTema(idTema, callback) {
        let query = "SELECT * FROM `mensajestema` WHERE `idTema` = ?;";
        const interrogation = [idTema];
        DAOUtil.read(pool, query, interrogation, MensajesTema.transform, callback);
    }


    // Insertar un nuevo mensaje en el tema
    static insertarMensaje(mensaje, callback) {
        console.log(mensaje);
        let query = "INSERT INTO `mensajestema` (`idTema`, `NombreUsuario`, `FotoUsuario`, `texto`) VALUES (?, ?, ?, ?);";
        const interrogation = [mensaje.idTema, mensaje.NombreUsuario, mensaje.FotoUsuario, mensaje.texto];

        DAOUtil.write(pool, query, interrogation, callback);
    }

}

module.exports = DAOMensajesTema;
