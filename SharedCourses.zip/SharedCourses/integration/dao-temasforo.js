"use strict"

const pool = require('../integration/pool-container');
const TemasForo = require('../integration/temasforo');
const DAOUtil = require('../integration/dao-utils');

class DAOTemasForo {

    // Leer todos los temas de foro por ID del curso
    static leerTemasForoPorIdCurso(idCurso, callback) {
        let query = "SELECT * FROM `temasforo` WHERE `idCurso` = ?;";
        const interrogation = [idCurso];
        DAOUtil.read(pool, query, interrogation, TemasForo.transform, callback);
    }

    // Insertar un nuevo tema de foro
    static insertarTemaForo(temaForo, callback) {
        let query = "INSERT INTO `temasforo` (`idCurso`, `NombreUsuario`, `FotoUsuario`, `TituloTema`) ";
        query += "VALUES (?, ?, ?, ?);";
        const interrogation = [
            temaForo.idCurso, temaForo.NombreUsuario, temaForo.FotoUsuario, temaForo.TituloTema
        ];
        DAOUtil.write(pool, query, interrogation, callback);
    }
    
}

module.exports = DAOTemasForo;
