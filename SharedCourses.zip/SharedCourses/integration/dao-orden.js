"use strict";

const pool = require('../integration/pool-container');
// [ DEBUG ]
if (typeof pool === 'undefined') {
    console.log('ERROR: \'Valor indefinido\'');
    console.log('   Lugar: dao-orden.js l.8');
    console.log('   Decripción: La variable pool no se ha inicializado correctamente');
}

const OrdenCompra = require('../integration/orden');
const DAOUtil = require('../integration/dao-utils');

class DAOOrden {

    // Insert a new order into the database
    static insertOrden(ordenCompra, callback) {
        let query = `
            INSERT INTO orden_compra 
            (id_curso, correo_usuario, num_usuarios_d, num_usuarios_c, precio_curso, precio_dividido, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        `;
        const interrogation = [
            ordenCompra.id_curso, ordenCompra.correo_usuario, ordenCompra.num_usuarios_d, 
            ordenCompra.num_usuarios_c, ordenCompra.precio_curso, ordenCompra.precio_dividido, 
            ordenCompra.estado
        ];
        DAOUtil.write(pool, query, interrogation, (error, result) => {
            if (error) {
                callback(error, null);
            } else {
                callback(null, result);
            }
        });
    }

        // Insert a new order into the database
        static insertOrdenAmigo(ordenCompra, callback) {
            let query = `
                INSERT INTO orden_compra 
                (id, id_curso, correo_usuario, num_usuarios_d, num_usuarios_c, precio_curso, precio_dividido, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            `;
            const interrogation = [
                ordenCompra.id, ordenCompra.id_curso, ordenCompra.correo_usuario, ordenCompra.num_usuarios_d, 
                ordenCompra.num_usuarios_c, ordenCompra.precio_curso, ordenCompra.precio_dividido, 
                ordenCompra.estado
            ];
            DAOUtil.write(pool, query, interrogation, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, result);
                }
            });
        }

    // Change the order state to 'en_cola' based on id_curso and correo_usuario
    static cambiarEstadoEnCola(id_curso, correo_usuario, callback) {
        let query = "UPDATE orden_compra SET estado = 'en_cola' WHERE id_curso = ? AND correo_usuario = ?;";
        const interrogation = [id_curso, correo_usuario];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    // Delete an order by id_curso and correo_usuario
    static deleteOrden(id_curso, correo_usuario, callback) {
        let query = "DELETE FROM orden_compra WHERE id_curso = ? AND correo_usuario = ?;";
        const interrogation = [id_curso, correo_usuario];
        DAOUtil.write(pool, query, interrogation, callback);
    }

    // Retrieve all orders from the database
    static readOrdenes(callback) {
        let query = "SELECT * FROM orden_compra;";
        const interrogation = [];
        DAOUtil.read(pool, query, interrogation, OrdenCompra.transform, callback);
    }

    // Retrieve orders by id_curso and correo_usuario
    static readOrdenByCorreo(correo_usuario, callback) {
        let query = "SELECT * FROM orden_compra WHERE correo_usuario = ?;";
        const interrogation = [correo_usuario];
        DAOUtil.read(pool, query, interrogation, OrdenCompra.transform, callback);
    }

    static checkExistingOrder(ordenData) {
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM orden_compra WHERE id_curso = ? AND correo_usuario = ?';
            const values = [ordenData.id_curso, ordenData.correo_usuario];
            pool.query(query, values, (err, rows) => {
                if (err) reject(err);
                else resolve(rows.length > 0);
            });
        });
    }
    
}

module.exports = DAOOrden;
