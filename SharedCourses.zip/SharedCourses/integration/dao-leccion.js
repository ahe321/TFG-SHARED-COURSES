"use strict"

const pool = require('../integration/pool-container');
const DAOUtil = require('../integration/dao-utils');
const Leccion = require('../integration/leccion');
const UserLesson = require('../integration/user-lesson');

class DAOLeccion {
    
    static insertLeccion(leccion, callback) {
        const query = `
            INSERT INTO leccion (idCurso, nombre, ruta)
            VALUES (?, ?, ?)
        `;
        pool.query(query, [leccion.idCurso, leccion.nombre, leccion.ruta], (err, result) => {
            if (err) return callback(err);
            callback(null, result.insertId);
        });
    }

    
    // Leer todas las lecciones
    static readLecciones(callback) {
        let query = "SELECT * FROM Leccion";
        DAOUtil.read(pool, query, [], Leccion.transform, (error, results) => {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, results);
        });
    }

    // Leer lecciones completadas por un usuario
    static readLeccionesCompletadas(idUsuario, callback) {
        let query = "SELECT idLeccion, idCurso FROM user_lesson WHERE idUsuario = ? AND completada = 1";
        const params = [idUsuario];
        
        DAOUtil.read(pool, query, params, UserLesson.transform, (error, results) => {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, results.map(row => ({ idLeccion: row.idLeccion, idCurso: row.idCurso })));
        });
    }


    static markLessonCompleted(idUsuario, idLeccion, idCurso, callback) {
        console.log(idUsuario,idLeccion,idCurso);
        let query = `
            INSERT INTO user_lesson (idUsuario, idLeccion, idCurso, completada)
            VALUES (?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE completada = 1
        `;
        const params = [idUsuario, idLeccion, idCurso];

        DAOUtil.write(pool, query, params, (error, results) => {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, { success: true, message: "Lección marcada como completada" });
        });
    }
}

module.exports = DAOLeccion;
