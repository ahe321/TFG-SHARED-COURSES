
// config.js
"use strict";

module.exports = {
    mysqlConfig: {
        host: "localhost",
        user:"root",
        password:"",
        database:"SH_CO",
        port: 3306
    },

    // Puerto en el que escucha el servidor
    port: 3000
};
