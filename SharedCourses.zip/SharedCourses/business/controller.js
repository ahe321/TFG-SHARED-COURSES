
// controller.js
"use strict"

const DAOUsuarios = require('../integration/dao-usuarios.js');
const DAOCursos = require('../integration/dao-cursos.js');
const DAONotificaciones = require('../integration/dao-notificacion.js');
const DAOOrden = require('../integration/dao-orden.js');
const DAOLeccion = require('../integration/dao-leccion.js');
const DAOCertificados = require('../integration/dao-certificado.js');
const DAOTemasForo = require('../integration/dao-temasforo.js');
const DAOMensajesTema = require('../integration/dao-mensajestema.js');
const DAORating = require('../integration/dao-rating.js');
const DAOTests = require('../integration/dao-tests.js');
const DAOEstadisticas = require('../integration/dao-estadisticas.js');
// const DAOMensajes = require('../integration/dao-mensajes.js');
const Usuario = require('../integration/usuario.js');
const PhotoDumper = require('../business/photo-dumper.js');
const Curso = require('../integration/curso.js');
const Notificacion = require('../integration/notificacion.js');
const OrdenCompra = require('../integration/orden.js');
const Leccion = require('../integration/leccion.js');
const UserLesson = require('../integration/user-lesson.js');
const Certificado = require('../integration/certificado.js');
const TemasForo = require('../integration/temasforo.js');
const MensajesTema = require('../integration/mensajestema.js');
const UserRating = require('../integration/user-rating.js');
const Test = require('../integration/tests.js');
const Estadisticas = require('../integration/estadisticas.js');


function toDate(fecha) {
    // Precondición: Obtenemos la fecha (String) en formato dd/mm/aaaa hh:mm

    const parts = fecha.split(/[/ :]/);
    const year = parts[2];
    const month = parts[1] - 1;
    const day = parts[0];
    const hour = parts[3];
    const minute = parts[4];

    const date = new Date(year, month, day, hour, minute);

    // Devolvemos la instancia de Date
    return date;
}

function toFecha(date) {
    // Precondición: Obtenemos la fecha (Date)

    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Los meses en JavaScript van de 0 a 11
    const year = date.getFullYear();
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');

    // Devolvemos la fecha en formato dd/mm/aaaa hh:mm
    return `${day}/${month}/${year} ${hour}:${minute}`;
}

const firstHour = 9;
const numHoras = 11;

class Controller {

    static getUsuarioByEmail(emailUsuario, callback) {
        // Llamamos al DAO para leer los datos del usuario por su id
        DAOUsuarios.readUsuarioByEmail(emailUsuario, (error, usuario) => {
            if (error) {
                callback(error, null);
            } else if (usuario === null) {
                callback(new Error("Usuario no encontrado"), null);
            } else {
                // Eliminamos la contraseña por seguridad
                //delete usuario.contrasena;
                delete usuario.validado;
                delete usuario.activo;
    
                // Si el usuario tiene foto, la convertimos a base64
                if (usuario.foto !== null) {
                    const b64 = Buffer.from(usuario.foto).toString('base64');
                    const mimeType = 'image/png'; // O el tipo adecuado dependiendo de la foto
                    usuario.foto = "data:" + mimeType + ";base64," + b64;
                }
    
                // Devolvemos el usuario procesado
                callback(null, usuario);
            }
        });
    }

    static actualizarUsuario(emailUsuario, nuevosDatos, callback) {
        // Si hay una nueva foto, convertirla a blob
        console.log(nuevosDatos)
        if (typeof nuevosDatos.foto !== 'undefined') {
        PhotoDumper.toBlob(nuevosDatos.foto, (error, blob) => {
            if (error) {
                callback(new Error("Error al procesar la foto"));
            } else {
                nuevosDatos.foto = blob;
                DAOUsuarios.updateUsuario(emailUsuario, nuevosDatos, callback);
            }
        });
        } else {
            // Actualizar usuario sin modificar la foto
            console.log("hola");
            DAOUsuarios.updateUsuarioSinFoto(emailUsuario, nuevosDatos, callback);
        }
    }
    
    
    static createUsuario(usuarioAspirante, callback) {
        DAOUsuarios.readUsuarioByEmail(usuarioAspirante.email, (error, usuario) => {
            if (error)
                callback(error);
            else if (usuario === null) {
                if (usuarioAspirante.foto !== null) {
                    PhotoDumper.toBlob(usuarioAspirante.foto, (error, blob) => {
                        if (error)
                            callback(new Error('Se ha producido un error al tratar la foto'));
                        else {
                            usuarioAspirante.foto = blob;
                            DAOUsuarios.insertUsuario(usuarioAspirante, callback);
                        }
                    });
                }
                else
                    DAOUsuarios.insertUsuario(usuarioAspirante, callback);
            }
            else
                callback(new Error("Ya existe un usuario con ese email"));
        });
    }

    static isLoginCorrect(correo, contrasena, callback) {
        DAOUsuarios.readUsuarioByEmail(correo, (error, usuario) => {
            if (error)
                callback(error, null);
            else if (usuario === null || usuario.contrasena !== contrasena) {
                // DEBUG
                /*
                console.log('AVISO: \'Login detectado\'');
                if (usuario === null)
                    console.log('   El correo no corresponde a ningún usuario');
                else
                    console.log(`   Las contraseñas no coinciden: ${usuario.contrasena} != ${contrasena}`);
                */
                callback(null, null);
            }
            else {
                // DEBUG
                // console.log(Usuario.toString(usuario))
                callback(null, usuario);
            }
        })
    }

    static getNuevosUsuarios(callback) {
        DAOUsuarios.readUsuariosByValidation(0, (error, usuarios) => {
            if (error)
                callback(error, null);
            else {
                usuarios.forEach(usuario => {
                    delete usuario.contrasena;
                    delete usuario.validado;
                    delete usuario.administrador;
                    delete usuario.activo;
                    if(usuario.foto !== null)
                    {
                        const b64 = Buffer.from(usuario.foto).toString('base64');
                        const mimeType = 'image/png';
                        usuario.foto = "data:" + mimeType + ";base64," + b64;
                    }
                })
                callback(null, usuarios);
            }
        });
    }

    static getUsuariosValidos(callback) {
        DAOUsuarios.readUsuariosByValidation(1, (error, usuarios) => {
            if (error)
                callback(error, null);
            else {
                usuarios.forEach(usuario => {
                    delete usuario.contrasena;
                    delete usuario.validado;
                    delete usuario.activo;
                    if(usuario.foto !== null)
                    {
                        const b64 = Buffer.from(usuario.foto).toString('base64');
                        const mimeType = 'image/png';
                        usuario.foto = "data:" + mimeType + ";base64," + b64;
                    }
                })
                callback(null, usuarios);
            }
        });
    }

    static aceptarUsuario(idUsuario, callback) {
        DAOUsuarios.validarUsuario(idUsuario, callback);
    }

    static rechazarUsuario(idUsuario, callback) {
        DAOUsuarios.deleteUsuario(idUsuario, callback);
    }

    static nombrarAdministrador(idUsuario, callback) {
        DAOUsuarios.nombrarAdministrador(idUsuario, callback);
    }

    static getAmigosByEmail(emailUsuario, callback) {
        DAOUsuarios.readAmigosByEmail(emailUsuario, (error, amigos) => {
            if (error) {
                callback(error, null);
            } else {
                amigos.forEach((amigo) => {
                    if (amigo.foto !== null) {
                        amigo.foto = `data:image/png;base64,${Buffer.from(amigo.foto).toString("base64")}`;
                    }
                });
                callback(null, amigos);
            }
        });
    }

    static agregarAmigo(correoUsuario, correoAmigo, callback) {
                // Buscamos al amigo por correo
                DAOUsuarios.readUsuarioByEmail(correoAmigo, (error, amigo) => {
                    if (error) {
                        callback(error);
                    } else if (amigo === null) {
                        callback(new Error('El amigo no existe.'));
                    } else {
                        // Verificamos si el amigo ya está en la lista de amigos del usuario
                        DAOUsuarios.readAmigosByEmail(correoUsuario, (error, amigos) => {
                            if (error) {
                                callback(error);
                            } else {
                                const yaSonAmigos = amigos.some(amigo => amigo.correo === correoAmigo);
                                if (yaSonAmigos) {
                                    callback(new Error('Ya son amigos.'));
                                } else {
                                    // Insertamos la relación de amistad usando los correos electrónicos
                                    DAOUsuarios.insertAmigosByEmail(correoUsuario, correoAmigo, (error) => {
                                        if (error) {
                                            callback(error);
                                        } else {
                                            callback(null);  // Amigo agregado correctamente
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
    }
    
    static eliminarAmigo(emailUsuario, emailAmigo, callback) {
        // Llamamos al DAOUsuarios para eliminar la relación de amistad entre los usuarios

        DAOUsuarios.deleteAmigoByEmail(emailUsuario, emailAmigo, (error) => {
            if (error) {
                callback(error);
            } else {
                // Devolvemos una respuesta indicando que la operación se realizó correctamente
                callback(null);
            }
        });
        
    }

    static getCursos(callback) {
        
        DAOCursos.readCursos( (error, cursos) => {
            if (error)
                callback(error, null);
            else {
                callback(null, cursos);
            }
        });
        
    }


    static getNotificacionesByEmail(emailUsuario, callback) {
        // Llamamos al DAO para obtener las notificaciones por el email del usuario
        DAONotificaciones.readNotificacionesByEmail(emailUsuario, (error, notificaciones) => {
            if (error) {
                callback(error, null);
            } else {
                // Devolvemos las notificaciones procesadas
                callback(null, notificaciones);
            }
        });
    }

    static marcarComoLeida(idMensaje, callback) {
        // Actualiza el estado de un mensaje a "leído" por su id
        DAONotificaciones.marcarComoLeida(idMensaje, (error) => {
            if (error) {
                callback(error);  // Si hay un error, lo pasamos al callback
            } else {
                callback(null);  // Si no hay error, devolvemos null
            }
        });
    }
    
    static eliminarNotificacion(idNotificacion, callback) {
        DAONotificaciones.deleteNotificacion(idNotificacion, (error) => {
            if (error) {
                callback(error);
            } else {
                callback(null);
            }
        });
    }

    static insertNotificacion(notificacion, callback) {
        // Primero, validamos que la notificación tenga los datos necesarios
        if (!notificacion.titulo || !notificacion.mensaje || !notificacion.correoUsuario) {
            callback(new Error('Faltan campos obligatorios en la notificación.'));
            return;
        }
    
        // Llamamos al DAO para insertar la notificación en la base de datos
        DAONotificaciones.insertNotificacion(notificacion, (error, result) => {
            if (error) {
                // Si ocurre un error al insertar, pasamos el error al callback
                callback(error);
            } else {
                // Si la inserción es exitosa, pasamos el resultado al callback
                callback(null, result);
            }
        });
    }



        // Obtener todas las órdenes
        static getOrdenes(callback) {
            DAOOrden.readOrdenes((error, ordenes) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, ordenes);
                }
            });
        }
    
        // Obtener órdenes de un usuario específico por correo
        static getOrdenesByCorreo(correo_usuario, callback) {
            DAOOrden.readOrdenByCorreo(correo_usuario, (error, ordenes) => {
                if (error) {
                    callback(error, null);
                } else if (!ordenes || ordenes.length === 0) {
                    callback(new Error('No se encontraron órdenes para este correo'), null);
                } else {
                    callback(null, ordenes);
                }
            });
        }
    
        // Crear una nueva orden
        static createOrden(ordenData, callback) {
            DAOOrden.insertOrden(ordenData, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, result);
                }
            });
        }

        static async createOrden(ordenData, correosAmigos, callback) {
            try {
                // Verifica si la orden principal ya existe
                const existingOrder = await DAOOrden.checkExistingOrder(ordenData);
                if (existingOrder) {
                    return callback(new Error("La orden ya existe"), null);
                }

                // Insertar la primera orden en la base de datos
                const result = await new Promise((resolve, reject) => {
                    DAOOrden.insertOrden(ordenData, (error, result) => {
                        if (error) reject(error);
                        else resolve(result);
                    });
                });
                
                // Obtener el ID generado
                const lastId = result.insertId;
        
                // Crear las órdenes para los amigos
                const ordenesAmigos = correosAmigos.map(correo => ({
                    id: lastId,
                    id_curso: ordenData.id_curso,
                    correo_usuario: correo,
                    num_usuarios_d: ordenData.num_usuarios_d,
                    num_usuarios_c: ordenData.num_usuarios_c,
                    precio_curso: ordenData.precio_curso,
                    precio_dividido: ordenData.precio_dividido,
                    estado: 'sin_confirmar' // Estado inicial para amigos
                }));

                // Comprobar si las órdenes de los amigos ya existen antes de insertarlas
                for (const orden of ordenesAmigos) {
                    const existingOrderAmigo = await DAOOrden.checkExistingOrder(orden);
                    if (existingOrderAmigo) {
                        return callback(new Error(`La orden para el amigo ${orden.correo_usuario} ya existe`), null);
                    }
                }
        
                // Insertar todas las órdenes de los amigos
                await Promise.all(
                    ordenesAmigos.map(orden => 
                        new Promise((resolve, reject) => {
                            DAOOrden.insertOrdenAmigo(orden, (error, result) => {
                                if (error) reject(error);
                                else resolve(result);
                            });
                        })
                        
                    )
                );
        
                // Si todo fue exitoso, llamamos al callback sin errores
                callback(null, { message: "Orden creada con éxito", id: lastId });
        
            } catch (error) {
                callback(error, null);
            }
        }
        
    
        // Cambiar el estado de una orden a 'en_cola'
        static cambiarEstadoEnCola(id_curso, correo_usuario, callback) {
            DAOOrden.cambiarEstadoEnCola(id_curso, correo_usuario, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, result);
                }
            });
        }
    
        // Eliminar una orden por id_curso y correo_usuario
        static deleteOrden(id_curso, correo_usuario, callback) {
            DAOOrden.deleteOrden(id_curso, correo_usuario, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, result);
                }
            });
        }

        static getLecciones(callback) {
            DAOLeccion.readLecciones((error, lecciones) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, lecciones);
                }
            });
        }

        static getLeccionesCompletadas(idUsuario, callback) {
            DAOLeccion.readLeccionesCompletadas(idUsuario, (error, leccionesCompletadas) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, leccionesCompletadas);
                }
            });
        }

        static markLessonCompleted(idUsuario, idLeccion, idCurso, callback) {
            DAOLeccion.markLessonCompleted(idUsuario, idLeccion, idCurso, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, result);
                }
            });
        }
        
        static getCertificadosPorUsuario(idUsuario, callback) {
            DAOCertificados.leerCertificadosPorIdUsuario(idUsuario, (error, certificados) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, certificados);
                }
            });
        }
    
        static insertarCertificado(certificadoData, callback) {
            DAOCertificados.insertarCertificado(certificadoData, (error, resultado) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, resultado);
                }
            });
        }

        static obtenerCertificadoPorCursoYUsuario(idCurso, idUsuario, callback) {
            DAOCertificados.obtenerCertificadoPorCursoYUsuario(idCurso, idUsuario, (error, certificado) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, certificado);
                }
            });
        }

        static getMensajesPorIdTema(idTema, callback) {
            DAOMensajesTema.leerMensajesPorIdTema(idTema, (error, mensajes) => {
                if (error) {
                    callback(error, null);
                } else {
                    mensajes.forEach(mensaje => {
                            const b64 = Buffer.from(mensaje.FotoUsuario).toString('base64');
                            const mimeType = 'image/png';
                            mensaje.FotoUsuario = "data:" + mimeType + ";base64," + b64;
                    })
                    callback(null, mensajes);
                }
            });
        }

        static leerTemasForoPorIdCurso(idCurso, callback) {
            DAOTemasForo.leerTemasForoPorIdCurso(idCurso, (error, temas) => {
                if (error) {
                    callback(error, null);
                } else {
                    temas.forEach(tema => {
                        const b64 = Buffer.from(tema.FotoUsuario).toString('base64');
                        const mimeType = 'image/png';
                        tema.FotoUsuario = "data:" + mimeType + ";base64," + b64;
                })
                    callback(null, temas);
                }
            });
        }

        static insertarTemaForo(temaForo, callback) {
            // Verificamos que el tema tenga los datos necesarios
                    console.log(temaForo);
                    temaForo.FotoUsuario = Buffer.from(temaForo.FotoUsuario.data);
                    // Llamamos al DAO para insertar el tema de foro en la base de datos
                    DAOTemasForo.insertarTemaForo(temaForo, (error, resultado) => {
                        if (error) {
                            callback(error, null); // Si hay un error, lo devolvemos
                        } else {
                            callback(null, resultado); // Devolvemos el resultado de la inserción
                        }
                    });
        }
    

        static insertarMensajeForo(mensajeForo, callback) {
            mensajeForo.FotoUsuario = Buffer.from(mensajeForo.FotoUsuario.data);
            // Llamamos al DAO para insertar el mensaje en la base de datos
            DAOMensajesTema.insertarMensaje(mensajeForo, (error, resultado) => {
                if (error) {
                    callback(error, null); // Si hay un error, lo devolvemos
                } else {
                    callback(null, resultado); // Devolvemos el resultado de la inserción
                }
            });
        }
        
        static insertRating(idUsuario, idCurso, rating, callback) {
        
            // Validar que no falten campos
            if (!idUsuario || !idCurso || rating == null) {
                callback(new Error('Faltan campos obligatorios para insertar rating.'));
                return;
            }
        
            // Llamada al DAO
            DAORating.insertRating(idUsuario, idCurso, rating, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, result);
                }
            });
        }


        static getTestsByIdLeccion(idLeccion, callback) {
            DAOTests.readTestsByIdLeccion(idLeccion, (error, tests) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, tests);
                }
            });
        }
        
        static getEstadisticas(callback) {
            DAOEstadisticas.obtenerEstadisticas((error, estadisticas) => {
                if (error) {
                    callback(error, null);
                } else {
                    // Procesamos las estadísticas antes de devolverlas
                    const estadisticasProcesadas = {
                        cursosTotales: estadisticas[0].cursosTotales,  // Ajustar el nombre de la propiedad
                        usuariosRegistrados: estadisticas[0].usuariosRegistrados,  // Ajustar el nombre de la propiedad
                        valoracionPromedio: estadisticas[0].valoracionPromedio,  // Ajustar el nombre de la propiedad
                        certificadosEmitidos: estadisticas[0].certificadosEmitidos,  // Ajustar el nombre de la propiedad
                    };
        
                    // Devolvemos las estadísticas procesadas
                    callback(null, estadisticasProcesadas);
                }
            });
        }   
        
static crearCurso(cursoData, files, body, callback) {
    const { name, description, long_description, duration, level, type, precio, image } = cursoData;

    // Insertar curso primero
    DAOCursos.insertCurso(
        { name, description, long_description, duration, level, type, precio, image },
        (err, cursoId) => {
            if (err) return callback(err);

            if (!body.lecciones || body.lecciones.length === 0) {
                return callback(null); // No hay lecciones
            }

            let pending = body.lecciones.length;

            body.lecciones.forEach((leccion, index) => {
                // Buscar archivo de video para esta lección (opcional)
                const videoFile = files.find(f => f.fieldname === `lecciones[${index}][video]`);
                const videoPath = videoFile ? `../public/videos/${videoFile.filename}` : null;

                DAOLeccion.insertLeccion(
                    { idCurso: cursoId, nombre: leccion.nombre, ruta: videoPath },
                    (err, leccionId) => {
                        if (err) return callback(err);

                        if (!leccion.tests || leccion.tests.length === 0) {
                            if (--pending === 0) callback(null);
                            return;
                        }

                        let pendingTests = leccion.tests.length;

                        leccion.tests.forEach(test => {
                            DAOTests.insertTest(
                                {
                                    idLeccion: leccionId,
                                    question: test.question,
                                    option1: test.option1,
                                    option2: test.option2,
                                    option3: test.option3,
                                    correct: test.correct
                                },
                                err => {
                                    if (err) return callback(err);
                                    if (--pendingTests === 0 && --pending === 0) callback(null);
                                }
                            );
                        });
                    }
                );
            });
        }
    );
}

    static eliminarUsuario(correoUsuario, callback) {
        // Llamamos al DAOUsuarios para eliminar el usuario
        DAOUsuarios.deleteUsuarioByEmail(correoUsuario, (error) => {
            if (error) {
                callback(error);
            } else {
                callback(null);
            }
        });
    }
    
}//fin controller



module.exports = Controller;