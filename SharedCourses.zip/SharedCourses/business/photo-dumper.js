
// photo-dumper.js
"use strict"

const sharp = require('sharp');
const fs = require('fs');

class PhotoDumper {

    static process(imagenBlob, callback) {
        sharp(imagenBlob)
            .toFormat('jpeg')
            .toBuffer()
            .then(jpgBuffer => callback(null, jpgBuffer))
            .catch(error => callback(error));
    }

    static toBlob(file, callback) {

        if (Buffer.isBuffer(file)) {
            // Si ya es un Buffer, lo devolvemos directamente
            return callback(null, file);
        }

        fs.readFile(file.path, (error, data) => {
            if (error)
                callback(error, null);
            else
                callback(null, data);
        });
    }
}

module.exports = PhotoDumper;