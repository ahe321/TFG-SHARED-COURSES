$(document).ready(() => {
  $("#loginButton").on("click", redirigirLogin);

  $("#registerButton").on("click", redirigirRegistro);

  $("#enrollButton").on("click", redirigirRegistro);

  $("#c").on("click", redirigirRegistro);

  $("#data").on("click", redirigirRegistro);

  $("#linux").on("click", redirigirRegistro);

  $("#web").on("click", redirigirRegistro);
});

function redirigirRegistro() {

  // Realizar la solicitud AJAX al servidor
  $.ajax({
      method: "GET",
      url: "/registro",
      success: function (response) {
          window.location.href = '/registro';
      },
      error: function (error) {
          window.location.href = error.redirectUrl;
      }
  });

}

function redirigirLogin() {

  // Realizar la solicitud AJAX al servidor
  $.ajax({
      method: "GET",
      url: "/login",
      success: function (response) {
        console.log(response.redirectUrl);
          window.location.href = '/login';
      },
      error: function (error) {
          window.location.href = error.redirectUrl;
      }
  });
}