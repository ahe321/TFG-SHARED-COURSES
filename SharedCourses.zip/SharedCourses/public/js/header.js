$(document).ready(function() {
  obtenerNotificaciones();

  // Evento para abrir el cuadro de notificaciones
  $('#notificacionesBtn').click(function(e) {
      obtenerNotificaciones(); // Recargar notificaciones antes de abrir
      toggleNotificacionesBox();
  });

  // Evento para cerrar el cuadro de notificaciones
  $('#closeNotificaciones').click(function() {
      $('#notificacionesBox').hide();
  });

  function toggleNotificacionesBox() {
      var btnPosition = $('#notificacionesBtn').offset();
      var btnHeight = $('#notificacionesBtn').outerHeight();

      $('#notificacionesBox').css({
          top: btnPosition.top + btnHeight + 5,
          left: btnPosition.left,
      }).toggle();
  }

  // Cerrar el cuadro de notificaciones
  $('#closeNotificaciones').click(function() {
    $('#notificacionesBox').hide();
  });

  // Abrir el modal con los detalles de la notificación
  $(document).on('click', '.notificacion', function() {
    var id = $(this).data('id'); // Obtenemos el ID de la notificación
    var title = 'Detalles'; // Título de la notificación
    var description = $(this).data('detalles'); // Descripción

    // Rellenar el modal con la información de la notificación
    $('#modalTitle').text(title);
    $('#modalDescription').text(description);

    // Mostrar el modal
    $('#notificacionModal').fadeIn();

    var notificacionElemento = $(this); // Guardamos el elemento clickeado
    var leida = $(this).data('leida'); 

    if(leida !== 1){
        // Marcar la notificación como leída mediante AJAX
        $.ajax({
          url: 'marcar-como-leida', // URL de la ruta para marcar como leída
          type: 'POST',
          data: { id: id }, // Pasar el ID de la notificación
          success: function(response) {
            // Actualizar visualmente la notificación sin recargar toda la lista
            notificacionElemento.removeClass('notificacion-no-leida'); // Quitar la clase de no leída
            notificacionElemento.data('leida', 1); 
            // Actualizar el contador restando una notificación no leída
            var notificacionesNoLeidas = $('.notificacion-no-leida').length;
            actualizarNotificaciones(notificacionesNoLeidas);
          },
          error: function(error) {
            console.error("Error al marcar la notificación como leída: ", error);
          }
        });
    }
  });

  // Cerrar el modal
  $('#closeModal').click(function() {
    $('#notificacionModal').fadeOut();
  });

  function actualizarNotificaciones(numero) {
    if (numero > 0) {
      $('#badgeNotificaciones').text(numero).show(); // Mostrar el contador si hay notificaciones
    } else {
      $('#badgeNotificaciones').hide(); // Ocultar si no hay notificaciones sin leer
    }
  }  


  $(document).on('click', '.eliminar-notificacion', function(event) {
    event.stopPropagation(); // Evita que se active el evento de abrir detalles

    var id = $(this).data('id');
    var notificacionElemento = $(this).closest('.notificacion');

    $.ajax({
        url: 'eliminar-notificacion', // Ruta en el servidor
        type: 'POST',
        data: { id: id },
        success: function(response) {
            notificacionElemento.remove(); // Eliminar del DOM

            var notificacionesNoLeidas = $('.notificacion-no-leida').length;
            actualizarNotificaciones(notificacionesNoLeidas);
        },
        error: function(error) {
            console.error("Error al eliminar la notificación: ", error);
        }
    });
});


function obtenerNotificaciones() {
  $.ajax({
      url: 'obtener-notificaciones',
      type: 'GET',
      success: function(response) {
          $('#notificacionesBox ul').empty(); // Limpiar antes de agregar nuevas

          if (response.notificaciones.length > 0) {
              response.notificaciones.forEach(function(notificacion) {
                  var notificacionClase = notificacion.leida === null ? 'notificacion-no-leida' : '';
                  var notificacionHTML = `
                  <li class="notificacion ${notificacionClase}" 
                      data-id="${notificacion.id}" 
                      data-leida="${notificacion.leida}" 
                      data-detalles="${notificacion.detalles}">
                      ${notificacion.mensaje} 
                      <button class="eliminar-notificacion" data-id="${notificacion.id}">
                          <i class="fas fa-trash-alt"></i> <!-- Icono de basura -->
                      </button>
                  </li>`;              
                  $('#notificacionesBox ul').append(notificacionHTML);
              });

              var notificacionesNoLeidas = $('.notificacion-no-leida').length;
              actualizarNotificaciones(notificacionesNoLeidas);
          } else {
              $('#notificacionesBox ul').append('<li>No tienes notificaciones no leídas.</li>');
          }
      },
      error: function(error) {
          console.error("Error al obtener las notificaciones: ", error);
      }
  });
}


});
