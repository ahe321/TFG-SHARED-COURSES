
// gestion-usuarios.js

$(document).ready(() => {
    // Cargar solicitudes al cargar la página
    // testObtenerSolicitudes();
    obtenerSolicitidudes();
});

// Obtener las solicitudes mediante AJAX
function obtenerSolicitidudes() {
    $.ajax({
        method: 'POST',
        url: '/obtener-nuevos-usuarios',
        data: null,
        success: (response) => {
            cargarSolicitudes(response.usuarios);
        },
        error: (error) => {
            showAlertModal(error.title, error.message);
        }
    });
}

// Test de obtener solicitudes
function testObtenerSolicitudes() {
    const solicitudes = [
        { id: 1, nombre: 'Juan', apellido1: 'Pérez', apellido2: 'Gómez', correo: 'juan@example.com', curso: '3', grupo: 'A', facultad: 'Ciencias', img:'https://bootdey.com/img/Content/avatar/avatar1.png' },
        { id: 2, nombre: 'Ana', apellido1: 'García', apellido2: 'López', correo: 'ana@example.com', curso: '2', grupo: 'B', facultad: 'Artes', img:'https://bootdey.com/img/Content/avatar/avatar3.png' },
    ];

    cargarSolicitudes(solicitudes);
}

// Cargar las solicitudes dadas
function cargarSolicitudes(solicitudes) {
    // Limpiar la lista
    $('#solicitudesList').empty();

    solicitudes.map(usuario => {
        if (!usuario.hasOwnProperty('foto') || usuario.foto === null || usuario.foto === undefined)
            usuario.foto = "img/defecto/usuario.png";
    });

    // Agregar cada solicitud a la lista
    solicitudes.forEach((solicitud, i) => {
        const listItem = `
            <tr class="align-middle">
                <td>
                    <img src="${solicitud.foto}" class="avatar sm rounded-pill me-3 flex-shrink-0" alt="Usuario ${i}">
                </td>
                <td>${solicitud.nombre} ${solicitud.apellido1} ${solicitud.apellido2}</td>
                <td>${solicitud.correo}</td>
                <td class="text-end">
                    <div class="dropdown">
                        <a data-bs-toggle="dropdown" href="#" class="btn p-1" aria-expanded="false">
                            <i class="fa fa-bars" aria-hidden="true"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="">
                            <a href="#!" class="dropdown-item" onclick="aceptarSolicitud(${solicitud.id})">Aceptar Usuario</a>
                            <a href="#!" class="dropdown-item" onclick="denegarSolicitud(${solicitud.id})">Denegar Usuario</a>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        $('#solicitudesList').append(listItem);
    });
}

// Aceptar una solicitud
function aceptarSolicitud(id) {
    // Petición AYAX para aceptar la solicitud
    $.ajax({
        method: 'POST',
        url: '/aceptar-usuario',
        data: { idUsuario: id },
        success: (response) => {
            showAlertModal(response.title, response.message);
            obtenerSolicitidudes();
        },
        error: (error) => {
            showAlertModal(error.responseJSON.title, error.responseJSON.message);
        }
    });
    
    //Recargar solicitudes
    console.log('Aceptar solicitud con ID:', id);
}

// Denegar una solicitud
function denegarSolicitud(id) {
    // Petición AYAX pararechazar la solicitud
    $.ajax({
        method: 'POST',
        url: '/rechazar-usuario',
        data: { idUsuario: id },
        success: (response) => {
            showAlertModal(response.title, response.message);
            obtenerSolicitidudes(); 
        },
        error: (error) => {
            showAlertModal(error.responseJSON.title, error.responseJSON.message);
        }
    });
}