$(document).ready(function () {
    const urlParams = new URLSearchParams(window.location.search);
    const idCurso = urlParams.get("idCurso");
    let currentIdTema = null;

    if (!idCurso) {
        alert("Error: No se proporcionó un idCurso.");
        return;
    }

    function getLessonNameFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('nombreLeccion') || 'Lección desconocida';
    }
    
    const nombreLeccion = getLessonNameFromUrl();
    document.getElementById("forumName").innerText = 'Foro de ' + nombreLeccion;
    

    // Cargar temas del foro al inicio
    function cargarTemas(callback) {
        $.ajax({
            url: "/leer-temas-foro",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ idCurso }),
            success: function (response) {
                console.log(response.temasForo);
                $("#topicsList").empty();
                response.temasForo.forEach(tema => {
                    const topicHTML = `
                        <div class="card topic-card p-3 mb-2" onclick="verTema('${tema.idTema}', '${tema.TituloTema}')">
                            <div class="d-flex align-items-center">
                                <img src="${tema.FotoUsuario}" class="user-avatar" alt="Usuario">
                                <div>
                                    <h5 class="mb-0">${tema.NombreUsuario}</h5>
                                    <p class="mb-0 text-muted">${tema.TituloTema}</p>
                                </div>
                            </div>
                        </div>`;
                    $("#topicsList").append(topicHTML);
                });
                if (callback) callback();
            },
            error: function () {
                //showAlertModal("Error", "No se ha podido cargar los temas del foro");
            }
        });
    }

    // Agregar un nuevo tema al foro
    $("#addTopicBtn").click(function (event) {
        event.preventDefault(); // Evita la recarga de la página
        const tituloTema = $("#newTopicTitle").val().trim();
        if (tituloTema === "") {
            alert("Por favor, ingrese un título para el tema.");
            return;
        }

        const nuevoTema = {
            idCurso,
            TituloTema: tituloTema,
            NombreUsuario: "Usuario Nuevo",
            FotoUsuario: "../img/defecto/usuario.png"
        };

        console.log(nuevoTema);

        $.ajax({
            url: "/insertar-tema-foro",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(nuevoTema),
            success: function () {
                $("#newTopicTitle").val("");
                cargarTemas();
            },
            error: function () {
                showAlertModal("Error", "No se ha podido insertar el tema");
            }
        });
    });

    // Ver mensajes de un tema
    window.verTema = function (idTema, tituloTema) {
        currentIdTema = Number(idTema);
        console.log(idTema);
        $("#topicTitle").text(tituloTema);
        $("#topicsList").hide();
        $("#topicDetail").hide();

        // Ocultar el campo de nuevo tema y el botón de publicar
        $("#newTopicTitle").hide();
        $("#addTopicBtn").hide();

        // Limpiar mensajes previos antes de la carga
        $("#messagesList").empty();
        cargarMensajes();
        
        // Mostrar la barra de carga
        $("#loadingBarContainer").show();
        $("#loadingBar").css("width", "0%");
    
        // Animar la barra de carga
        let progress = 0;
        let interval = setInterval(function () {
            progress += 20; // Incrementa la barra cada 400ms
            $("#loadingBar").css("width", progress + "%");
            if (progress >= 100) {
                clearInterval(interval);
                $("#loadingBarContainer").hide();
                $("#topicDetail").show(); // Muestra los mensajes tras la carga
            }
        }, 200); // Total: 5 pasos de 400ms = 2s
    };

    

    // Cargar mensajes del tema
    function cargarMensajes(callback) {
        $.ajax({
            url: "/get-mensajes",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ idTema: currentIdTema }),
            success: function (response) {
                $("#messagesList").empty();
                response.mensajes.forEach(msg => {
                    const mensajeHTML = `
                        <div class="message">
                            <img src="${msg.FotoUsuario}" alt="Usuario">
                            <div>
                                <strong>${msg.NombreUsuario}</strong>
                                <p class="mb-0">${msg.texto}</p>
                            </div>
                        </div>`;
                    $("#messagesList").append(mensajeHTML);
                });
                if (callback) callback();
            },
            error: function (error) {
                $("#messagesList").empty();
                console.log("Foro vacio");
            }
        });
    }

    // Volver a la lista de temas
    $("#goBackBtn").click(function () {
        $("#topicDetail").hide();
        $("#topicsList").show();
        // Mostrar el campo de nuevo tema y el botón de publicar nuevamente
        $("#newTopicTitle").show();
        $("#addTopicBtn").show();
        $("#loadingBarContainer").hide(); // Ocultar la barra de carga al volver
        $("#newMessage").val(""); // Limpia el campo de entrada del mensaje
    });


    // Función para enviar un mensaje
    function enviarMensaje() {
        const textoMensaje = $("#newMessage").val().trim();
        if (textoMensaje === "") {
            alert("Por favor, ingrese un mensaje.");
            return;
        }

        const nuevoMensaje = {
            idTema: currentIdTema,
            texto: textoMensaje
        };

        $.ajax({
            url: "/insertar-mensaje-foro",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(nuevoMensaje),
            success: function () {
                $("#messageInput").val("");
                cargarMensajes(); // Recargar mensajes tras enviar uno nuevo
            },
            error: function () {
                showAlertModal("Error", "No se ha podido enviar el mensaje.");
            }
        });
    }

    // Evento para el botón de enviar mensaje
    $("#sendMessageBtn").click(function () {
        enviarMensaje();
    });

    // Cargar temas al iniciar
    cargarTemas();
});



function showAlertModal(title, message) {
    // Mostrar un modal de Bootstrap con el mensaje de error
    const modalHtml = `
        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        ${message}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Agregar el modal al cuerpo del documento
    $(document.body).append(modalHtml);
    
    // Mostrar el modal
    $('#errorModal').modal('show');
    
    // Eliminar el modal del DOM después de cerrarlo
    $('#errorModal').on('hidden.bs.modal', function () {
        $(this).remove();
    });
    }