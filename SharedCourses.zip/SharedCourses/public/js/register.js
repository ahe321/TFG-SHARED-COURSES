
$(document).ready(() =>{
    $("#registrarse-btn").on("click", submitSignupForm);

    $("#togglePassword").on("click", togglePassword);
});


function submitSignupForm() {
    // Obtener datos del formulario
    const formData = new FormData();
    formData.append("nombre", document.getElementsByName("FullName")[0].value);
    formData.append("apellido1", document.getElementsByName("Surname1")[0].value);
    formData.append("apellido2", document.getElementsByName("Surname2")[0].value);
    formData.append("correo", document.getElementsByName("Email")[0].value);
    formData.append("contrasena", document.getElementsByName("Password")[0].value);

    // Obtener el archivo de la entrada de imagen
    const profilePicFile = $("#file")[0].files[0];
    formData.append("file", profilePicFile);

    const nombre = formData.get("nombre");
    const apellido1 = formData.get("apellido1");
    const apellido2 = formData.get("apellido2");
    const correo = formData.get("correo");
    const contrasena = formData.get("contrasena");

    // Validar los campos del formulario
    if (!validateFormData(nombre, apellido1, apellido2, correo, contrasena)) {
        return;  // Salir si hay errores de validación
    }
    
    

    // Realizar la petición a Express.js
    $.ajax({
        type: "POST",
        url: "/crear-usuario",
        data: formData,
        contentType: false,  // No establecer contentType 
        processData: false,  // No procesar los datos
        success: function (response) {
            // Manejar la respuesta del servidor (éxito)
            showAlertModal("Registro Completado", "Se le enviará un correo de confirmación si los datos proporcionados son correctos");
            console.log(response);
        },
        error: function (error) {
            // Manejar la respuesta del servidor (error)
            showAlertModal("Error", "Ha ocurrido un error, intente registrarse de nuevo más tarde");
        }
    });
}


function validateFormData(nombre, apellido1, apellido2, correo, contrasena) {

//Validar nombre
if (isEmpty(nombre)) {
    showAlertModal("Error", "El campo 'Nombre' no puede estar vacío");
    return false;
}

if(!isValidAlphabeticString(nombre)){
    showAlertModal("Error","El campo 'Nombre' solo puede contener letras y no puede haber espacios");
    return false;
}

//Validar apellido1
if (isEmpty(apellido1)) {
    showAlertModal("Error", "El campo 'Primer Apellido' no puede estar vacío");
    return false;
}

if(!isValidAlphabeticString(apellido1)){
    showAlertModal("Error","El campo 'Primer Apellido' solo puede contener letras y no puede haber espacios");
    return false;
}

//Validar apellido2
if (isEmpty(apellido2)) {
    showAlertModal("Error", "El campo 'Segundo Apellido' no puede estar vacío");
    return false;
}

if(!isValidAlphabeticString(apellido2)){
    showAlertModal("Error","El campo 'Segundo Apellido' solo puede contener letras y no puede haber espacios");
    return false;
}


//Validar correo

if (isEmpty(correo)) {
    showAlertModal("Error", "El campo 'Correo Electrónico' no puede estar vacío");
    return false;
}

if (!isValidUCMEmail(correo)) {
    showAlertModal("Error", "El campo 'Correo Electrónico' debe ser un correo @ucm.es");
    return false;
}

//Validar contraseña

if (isEmpty(contrasena)) {
    showAlertModal("Error", "El campo 'Contraseña' no puede estar vacío");
    return false;
}

if (contrasena.length < 6) {
    showAlertModal("Error", "La contraseña debe tener al menos 6 caracteres");
    return false;
}

return true;  // Retorna true si no hay errores de validación
}

function isValidAlphabeticString(value) {
// Expresión regular para validar que la cadena solo contenga letras y no haya espacios
const alphabeticStringRegex = /^[A-Za-z]+$/;
return alphabeticStringRegex.test(value);
}

function isValidUCMEmail(email) {
// Expresión regular para validar que el correo sea de formato @ucm.es
const ucmEmailRegex = /^[^\s@]+@ucm\.es$/;
return ucmEmailRegex.test(email);
}

function isValidNumber(value) {
// Expresión regular para validar que el valor sea un número
const numberRegex = /^[0-9]+$/;
return numberRegex.test(value);
}

function isValidSingleLetter(value) {
// Expresión regular para validar que el valor sea una sola letra
const singleLetterRegex = /^[A-Za-z]$/;
return singleLetterRegex.test(value);
}

function isEmpty(value) {
return value.trim() === '';
}

function showAlertModal(title, message) {
// Mostrar un modal de Bootstrap con el mensaje de error
const modalHtml = `
    <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="errorModalLabel">${title}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ${message}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
`;

// Agregar el modal al cuerpo del documento
$(document.body).append(modalHtml);

// Mostrar el modal
$('#errorModal').modal('show');

// Eliminar el modal del DOM después de cerrarlo
$('#errorModal').on('hidden.bs.modal', function () {
    $(this).remove();
});
}

function togglePassword() {
const password = document.getElementsByName("Password")[0];
const togglePasswordIcon = document.querySelector("#togglePassword");

const type = password.getAttribute("type") === "password" ? "text" : "password";
password.setAttribute("type", type);

if (togglePasswordIcon.classList.contains("bi-eye-slash")) {
    togglePasswordIcon.classList.remove("bi-eye-slash");
    togglePasswordIcon.classList.add("bi-eye");
} else {
    togglePasswordIcon.classList.remove("bi-eye");
    togglePasswordIcon.classList.add("bi-eye-slash");
}
}
