$(document).ready(() => {
    obtenerAmigos(); // Cargar amigos al cargar la página
});

// Obtener amigos mediante AJAX
function obtenerAmigos() {
    $('#solicitudesList').html('<tr><td colspan="4" class="text-center">Cargando...</td></tr>');

    $.ajax({
        method: 'POST',
        url: '/obtener-amigos',
        data: null,
        success: (response) => {
            cargarAmigos(response.amigos);
        },
        error: (error) => {
            $('#solicitudesList').html('<tr><td colspan="4" class="text-center text-danger">Error al cargar la lista de amigos</td></tr>');
        }
    });
}

// Cargar la lista de amigos en la tabla
function cargarAmigos(amigos) {
    $('#solicitudesList').empty();

    amigos.forEach((amigo, i) => {
        if (!amigo.foto) {
            amigo.foto = "img/defecto/usuario.png";
        }

        const listItem = `
            <tr class="align-middle">
                <td>
                    <img src="${amigo.foto}" class="avatar sm rounded-pill me-3 flex-shrink-0" alt="Usuario ${i}">
                </td>
                <td>${amigo.nombre} ${amigo.apellido1} ${amigo.apellido2}</td>
                <td>${amigo.correo}</td>
                <td class="text-end">
                    <button class="btn btn-danger eliminar-amigo" data-id="${amigo.correo}">
                        <i class="fa fa-trash"></i> Eliminar
                    </button>
                </td>
            </tr>
        `;
        $('#solicitudesList').append(listItem);
    });
}

// Eliminar amigo
$(document).on('click', '.eliminar-amigo', function () {
    const correo = $(this).data('id');
    $.ajax({
        method: 'POST',
        url: '/eliminar-amigo',
        data: { correoAmigo: correo },
        success: (response) => {
            showAlertModal(response.title, response.message);
            obtenerAmigos(); // Recargar lista
        },
        error: (error) => {
            showAlertModal(error.responseJSON.title, error.responseJSON.message);
        }
    });
});

// Agregar nuevo amigo
$('#agregarAmigoForm').submit(function (e) {
    e.preventDefault();
    
    const correoAmigo = $('#correoAmigo').val();

    $.ajax({
        method: 'POST',
        url: '/agregar-amigo',
        data: { correoAmigo },
        success: (response) => {
            showAlertModal(response.title, response.message);
            $('#correoAmigo').val('');
            obtenerAmigos(); // Recargar lista
        },
        error: (error) => {
            showAlertModal(error.responseJSON.title, error.responseJSON.message);
        }
    });
});
