$(document).ready(function () {
    function obtenerCompras() {
        $.ajax({
            url: "/ordenes-por-correo",
            method: "GET",
            dataType: "json",
            success: function (data) {
                if (!data.ordenes || data.ordenes.length === 0) {
                    console.warn("No hay compras registradas");
                    return;
                }
                const comprado = data.ordenes.filter(orden => orden.estado === 'comprado');
                cargarCompras(comprado);
            },
            error: function (xhr, status, error) {
                console.error("Error al obtener órdenes:", error);
                showAlertModal("Aviso", "No se encontraron compras");
            }
        });
    }

    function cargarCompras(ordenes) {
        const idsCursos = ordenes.map(orden => orden.id_curso);
        $.ajax({
            url: "/obtener-cursos",
            method: "GET",
            dataType: "json",
            success: function (data) {
                const cursosRelacionados = data.cursos.filter(curso => idsCursos.includes(curso.id));
                mostrarComprasEnTabla(ordenes, cursosRelacionados);
            },
            error: function (xhr, status, error) {
                console.error("Error al obtener cursos:", error);
                alert("Hubo un error al obtener los cursos.");
            }
        });
    }

    function mostrarComprasEnTabla(ordenes, cursos) {
        const tbody = $("#comprasList");
        tbody.empty();

        ordenes.forEach(orden => {
            const curso = cursos.find(c => c.id === orden.id_curso);
            if (!curso) return;

            const fila = $(
`
                <tr>
                    <td>${formatearFecha(orden.fecha_emision)}</td>
                    <td>${formatearFecha(orden.fecha_cobro)}</td>
                    <td>${curso.name}</td>
                    <td>€${orden.precio_dividido}</td>
                    <td>
                        <button class="btn btn-warning btn-ver-factura"
                            data-id="${orden.id}"
                            data-nombre="${curso.name}"
                            data-emision="${orden.fecha_emision}"
                            data-cobro="${orden.fecha_cobro}"
                            data-precio="${orden.precio_dividido}">
                            Ver Factura
                        </button>
                    </td>
                </tr>
            `
            );
            tbody.append(fila);
        });
    }

    obtenerCompras();
});

$(document).on("click", ".btn-ver-factura", function () {
    const nombreCurso = $(this).data("nombre");
    const fechaEmision = formatearFecha($(this).data("emision"));
    const fechaCobro = formatearFecha($(this).data("cobro"));
    const precio = $(this).data("precio");

    $("#factura-curso").text(nombreCurso);
    $("#factura-emision").text(fechaEmision);
    $("#factura-cobro").text(fechaCobro);
    $("#factura-precio").text(precio.toFixed(2));

    let modal = new bootstrap.Modal(document.getElementById("facturaModal"));
    modal.show();
});

document.getElementById("descargarFactura").addEventListener("click", function () {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Añadir el logo de la empresa
    const logo = 'img/sharedcourses_icon.png'; // Ruta del logo
    doc.addImage(logo, 'PNG', 10, 10, 30, 30); // 10, 10 son las coordenadas, 30x30 el tamaño

    // Título de la factura
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text("Factura del Curso", 50, 20);  // Título desplazado para dejar espacio para el logo

    // Detalles de la factura
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.text(`Curso: ${$("#factura-curso").text()}`, 20, 50);
    doc.text(`Fecha de emisión: ${$("#factura-emision").text()}`, 20, 60);
    doc.text(`Fecha de cobro: ${$("#factura-cobro").text()}`, 20, 70);
    doc.text(`Precio total: €${$("#factura-precio").text()}`, 20, 80);
    doc.text("Factura generada por: SharedCourses", 20, 100);

    // Añadir línea divisoria para un diseño más limpio
    doc.setLineWidth(0.5);
    doc.line(10, 110, 200, 110);  // Línea horizontal

    // Final de la factura
    doc.text("Gracias por confiar en nosotros. Para más información, visita www.sharedcourses.com", 20, 120);

    // Guardar PDF
    doc.save("Factura.pdf");
});



function formatearFecha(fechaISO) {
    const fecha = new Date(fechaISO);
    return fecha.toLocaleDateString("es-ES"); 
}
