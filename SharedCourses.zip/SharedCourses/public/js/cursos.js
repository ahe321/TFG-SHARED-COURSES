    // Datos de cursos simulados
    let courses = [
        { name: "Curso de Tecnología", description: "Aprende desarrollo web.", duration: "Media", level: "Intermedio", image: "../public/img/tecnology.jpg" },
        { name: "Curso de Arte", description: "Desarrolla habilidades artísticas.", duration: "Larga", level: "Avanzado", image: "../public/img/arte.jpg" },
        { name: "Curso de Negocios", description: "Gestiona tu propio negocio.", duration: "Corta", level: "Principiante", image: "../public/img/negocio.jpg" },
        { name: "Curso de Programación", description: "Domina lenguajes como JavaScript y HTML", duration: "Media", level: "Intermedio", image: "../public/img/programming.png" },
        { name: "Curso de Marketing", description: "Estrategias para el mundo digital.", duration: "Larga", level: "Avanzado", image: "../public/img/marketing.png" },
        { name: "Curso de Diseño", description: "Aprende UX/UI y herramientas de diseño.", duration: "Media", level: "Intermedio", image: "../public/img/diseno.png" },
        { name: "Curso de Fotografía", description: "Domina la fotografía profesional.", duration: "Corta", level: "Principiante", image: "../public/img/fotografia.jpg" },
        { name: "Curso de Finanzas", description: "Gestión financiera para negocios.", duration: "Larga", level: "Avanzado", image: "../public/img/finanzas.jpg" }
    ];

    let filteredCourses = [];

    const coursesPerPage = 3;
    let currentPage = 1;

    function fetchCourses() {
        $.ajax({
            url: "obtener-cursos", // Reemplázalo con tu endpoint real
            method: "GET",
            dataType: "json",
            success: function (data) {
                courses = data.cursos; // Guardar los cursos obtenidos
                filteredCourses = data.cursos;
                renderCourses();
            },
            error: function (error) {
                console.error("Error al obtener los cursos:", error);
                showAlertModal("Error", "Ha ocurrido un error al obtener la lista de cursos, actualice la página o intentelo de nuevo más tarde");
            }
        });
    }

    function filterCourses() {
        const type = document.getElementById("course-type").value;
        const name = document.getElementById("course-name").value.toLowerCase();
        const level = document.getElementById("course-level").value.trim().toLowerCase();
        const duration = document.getElementById("course-duration").value.trim().toLowerCase();
    
        filteredCourses = courses.filter(course => {
            console.log(course)
            return (
                (type === "" || course.type === type) &&
                (name === "" || course.name.toLowerCase().includes(name)) &&
                (level === "" || course.level.toLowerCase() === level) &&
                (duration === "" || course.duration.toLowerCase() === duration)
            );
        });
    
        currentPage = 1; // Reiniciar paginación
    }

    function renderCourses() {
        const courseContainer = document.getElementById("course-container");
        courseContainer.innerHTML = ""; // Limpiar cursos previos

        // Ordenamos los cursos basados en la preferencia del usuario
        if (preferenciasUsuario !== "ninguna") {
            filteredCourses.sort((a, b) => {
                // Si el curso tiene el mismo tipo que la preferencia, se pone al principio
                if (a.type === preferenciasUsuario && b.type !== preferenciasUsuario) {
                    return -1;  // A va antes que B
                } else if (a.type !== preferenciasUsuario && b.type === preferenciasUsuario) {
                    return 1;   // B va antes que A
                }
                return 0;  // No hay cambio en el orden si ambos son iguales
            });
        }
    
        const totalPages = Math.ceil(filteredCourses.length / coursesPerPage);
        currentPage = Math.min(currentPage, totalPages) || 1; // Evitar páginas vacías
    
        const start = (currentPage - 1) * coursesPerPage;
        const end = start + coursesPerPage;
        const currentCourses = filteredCourses.slice(start, end);
    
        currentCourses.forEach(course => {
            const courseCard = `
                <div class="col-md-4">
                    <div class="card course-card">
                        <img src="${course.image}" class="card-img-top course-image" alt="${course.name}">
                        <div class="card-body">
                            <h5 class="card-title">${course.name}</h5>
                            <p class="card-text">${course.description}</p>
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#courseModal" 
                                    data-course-id="${course.id}"
                                    data-course-name="${course.name}"
                                    data-course-description="${course.long_description}"
                                    data-course-duration="${course.duration}"
                                    data-course-level="${course.level}"
                                    data-course-precio="${course.precio}"
                                    data-course-rating="${course.rating}"
                                    data-course-image="${course.image}">Ver más</button>
                        </div>
                    </div>
                </div>
            `;
            courseContainer.innerHTML += courseCard;
        });
    
        // Actualizar la información de la paginación
        const pageInfo = document.getElementById("page-info");
        pageInfo.textContent = totalPages > 0 ? `Página ${currentPage} de ${totalPages}` : "No hay cursos disponibles";
    
        // Mostrar u ocultar botones de paginación según sea necesario
        document.getElementById("prev-page").style.display = totalPages > 1 ? "inline-block" : "none";
        document.getElementById("next-page").style.display = totalPages > 1 ? "inline-block" : "none";
    
        document.getElementById("prev-page").disabled = currentPage === 1;
        document.getElementById("next-page").disabled = currentPage === totalPages;
    }
    

    document.getElementById("prev-page").addEventListener("click", () => {
        if (currentPage > 1) {
            currentPage--;
            renderCourses();
        }
    });

    document.getElementById("next-page").addEventListener("click", () => {
        if (currentPage < Math.ceil(courses.length / coursesPerPage)) {
            currentPage++;
            renderCourses();
        }
    });

    // Aplicar filtros al enviar el formulario
document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault();
    filterCourses();
    renderCourses();
});

    // Cargar cursos en la primera carga
    $(document).ready(() => {
        obtenerPreferencias();
        fetchCourses();
        obtenerAmigos();
    });
    
    function showAlertModal(title, message) {
        // Mostrar un modal de Bootstrap con el mensaje de error
        const modalHtml = `
            <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="errorModalLabel">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ${message}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Agregar el modal al cuerpo del documento
        $(document.body).append(modalHtml);
        
        // Mostrar el modal
        $('#errorModal').modal('show');
        
        // Eliminar el modal del DOM después de cerrarlo
        $('#errorModal').on('hidden.bs.modal', function () {
            $(this).remove();
        });
        }

        // Lista simulada de amigos con correos
        let amigos = [
            "juan@example.com",
            "maria@example.com",
            "carlos@example.com",
            "ana@example.com",
            "pedro@example.com"
        ];

        function obtenerAmigos() {
            $.ajax({
                url: "obtener-amigos", 
                method: "POST",
                data: null,
                success: function (response) {
                    // Verificamos que la respuesta tenga la estructura esperada
                    if (response && response.amigos && Array.isArray(response.amigos)) {
                        // Extraemos los correos de cada amigo y los almacenamos en el array amigos
                        amigos = response.amigos.map(amigo => amigo.correo);
                        console.log("Correos de amigos obtenidos:", amigos); // Verifica los correos en consola
                    } else {
                        console.error("La respuesta no tiene la estructura esperada.");
                    }
                },
                error: function (error) {
                    console.error("Error al obtener los amigos:", error);
                }
            });
        }

let seleccionados = [];
const maxSeleccionados = 5;

document.addEventListener("DOMContentLoaded", function () {
    // Agregar campo de selección al modal
    let modalFooter = document.querySelector("#courseModal .modal-footer");
    modalFooter.insertAdjacentHTML("beforebegin", `
        <div class="p-3">
            <label for="email-selector" class="form-label">Dividir precio entre amigos</label>
            <input type="text" id="email-selector" class="form-control" placeholder="Buscar amigo">
            <div id="suggestions" class="list-group mt-1"></div>
            <div id="selected-emails" class="mt-2"></div>
            <p id="limit-warning" class="text-danger mt-2" style="display: none;">Has alcanzado el límite de 5 amigos seleccionados.</p>
        </div>
    `);

    let inputSelector = document.getElementById("email-selector");
    let suggestions = document.getElementById("suggestions");
    let selectedEmails = document.getElementById("selected-emails");
    let limitWarning = document.getElementById("limit-warning");

    inputSelector.addEventListener("input", function () {
        let query = inputSelector.value.toLowerCase();
        suggestions.innerHTML = "";

        if (query && seleccionados.length < maxSeleccionados) {
            let filtered = amigos.filter(email => email.includes(query) && !seleccionados.includes(email));
            filtered.forEach(email => {
                let item = document.createElement("button");
                item.classList.add("list-group-item", "list-group-item-action");
                item.textContent = email;
                item.addEventListener("click", function () {
                    if (seleccionados.length < maxSeleccionados) {
                        seleccionados.push(email);
                        updateSelectedEmails();
                        inputSelector.value = "";
                        suggestions.innerHTML = "";
                    }
                });
                suggestions.appendChild(item);
            });
        }
    });

    function updateSelectedEmails() {
        selectedEmails.innerHTML = "";
        seleccionados.forEach(email => {
            let badge = document.createElement("span");
            badge.classList.add("badge", "bg-primary", "m-1");
            badge.textContent = email;
            let removeBtn = document.createElement("button");
            removeBtn.classList.add("btn-close", "ms-2");
            removeBtn.addEventListener("click", function () {
                seleccionados = seleccionados.filter(e => e !== email);
                updateSelectedEmails();
            });
            badge.appendChild(removeBtn);
            selectedEmails.appendChild(badge);
        });

        if (seleccionados.length >= maxSeleccionados) {
            limitWarning.style.display = "block";
        } else {
            limitWarning.style.display = "none";
        }
    }

    // Limpiar la selección cuando se cierre el modal
    $('#courseModal').on('hidden.bs.modal', function () {
        seleccionados = []; // Reiniciar lista de seleccionados
        selectedEmails.innerHTML = ""; // Limpiar la UI
        inputSelector.value = ""; // Limpiar el input
        suggestions.innerHTML = ""; // Limpiar las sugerencias
        limitWarning.style.display = "none"; // Ocultar advertencia de límite
    });
});

function enviarNotificaciones(curso, usuariosSeleccionados) {
    // Creamos el objeto de la notificación
    const totalPersonas = usuariosSeleccionados.length + 1;
    const precio = parseFloat(curso.precio.replace(/\D/g, '')) / totalPersonas;

    usuariosSeleccionados.forEach(correoUsuario => {
        const notificacion = {
            titulo: "Solicitud para dividir el precio de un curso",
            mensaje: ` quiere hacer una compra compartida por el valor de ${precio}€ de ${curso.name} contigo.`,
            correoUsuario: correoUsuario,
            detalles: "Si estás interesado en el curso, accede a la pestaña de mis cursos y acepta la solicitud."
        };

        console.log(JSON.stringify(notificacion));

        // Enviar la notificación a cada usuario seleccionado
        $.ajax({
            url: "enviar-notificacion", // La URL de tu ruta para enviar notificaciones
            method: "POST",
            data: notificacion,
            success: function (response) {
                console.log("Notificación enviada a " + correoUsuario);
            },
            error: function (error) {
                console.error("Error al enviar la notificación a " + correoUsuario, error);
            }
        });
    });
}


function crearOrden(curso, amigosSeleccionados) {
    const ordenData = {
        id_curso: curso.id,
        correo_usuario: "usuario@example.com",
        num_usuarios_d: amigosSeleccionados.length + 1,
        num_usuarios_c: 1,
        precio_curso: parseFloat(curso.precio.replace(/\D/g, '')),
        precio_dividido: parseFloat(curso.precio.replace(/\D/g, '')),
        estado: "en_cola",
        image: curso.image,
        nombre_curso: curso.name,
        descripcion: curso.description
    };

    console.log(ordenData);

    /*
    $.ajax({
        url: "crear-orden",
        method: "POST",
        contentType: "application/json",
        data: JSON.stringify({ ordenData, correosAmigos: amigosSeleccionados }),
        success: function (response) {
            console.log("Orden creada:", response);
            showAlertModal("Éxito", "La orden se ha creado correctamente.");
        },
        error: function (error) {
            console.error("Error al crear la orden:", error);
            showAlertModal("Error", error.responseJSON.message);
        }
    });
    */
   $.ajax({
    url: "crear-orden",
    method: "POST",
    contentType: "application/json",
    data: JSON.stringify({ ordenData, correosAmigos: amigosSeleccionados }),
    success: function (response) {
        // Redirigir a Stripe Checkout
        window.location.href = response.checkoutUrl;
    },
    error: function (error) {
        console.error("Error al crear la orden:", error);
        showAlertModal("Error", error.responseJSON.message);
    }
});

}


let courseId;

$('#courseModal').on('shown.bs.modal', function (event) {
    // Obtener el botón que activó el modal
    const button = $(event.relatedTarget); 
    courseId = button.data('course-id');
});


document.getElementById("inscribir-btn").addEventListener("click", function () {
    // Obtener los datos del curso desde los atributos del modal

    let curso = {
        id: courseId,
        name: document.getElementById("modal-course-name").textContent,
        description: document.getElementById("modal-course-description").textContent,
        duration: document.getElementById("modal-course-duration").textContent,
        level: document.getElementById("modal-course-level").textContent,
        precio: document.getElementById("modal-course-precio").textContent,
        image: document.getElementById("modal-course-image").src
    };

    // Obtener los correos seleccionados
    let usuariosSeleccionados = seleccionados;

    if (usuariosSeleccionados.length > 0) {
        // Llamamos a la función para enviar las notificaciones
        enviarNotificaciones(curso, usuariosSeleccionados);
        crearOrden(curso, usuariosSeleccionados);
    } else {
        crearOrden(curso, usuariosSeleccionados);
    }
});

let preferenciasUsuario = "";

function obtenerPreferencias() {
    $.ajax({
        url: "/get-preferencia", // Ruta que obtendrá las preferencias
        method: "GET",
        dataType: "json",
        success: function (response) {
            if (response.preferencias) {
                preferenciasUsuario = response.preferencias;  // Esto será una cadena como "arte", "negocios", "tecnología" o "ninguna"
                console.log("Preferencia del usuario:", preferenciasUsuario);
                filterCourses();  // Aplica los filtros de cursos según la preferencia
                renderCourses();  // Vuelve a renderizar los cursos filtrados
            }
        },
        error: function (error) {
            console.error("Error al obtener las preferencias:", error);
            showAlertModal("Error", "No se pudo obtener las preferencias del usuario.");
        }
    });
}

    
  document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("status") === "success") {
      // Crear modal básico
      const modal = document.createElement("div");
      modal.style.position = "fixed";
      modal.style.top = "0";
      modal.style.left = "0";
      modal.style.width = "100%";
      modal.style.height = "100%";
      modal.style.backgroundColor = "rgba(0,0,0,0.6)";
      modal.style.display = "flex";
      modal.style.alignItems = "center";
      modal.style.justifyContent = "center";
      modal.innerHTML = `
        <div style="
          background: white; 
          padding: 2rem; 
          border-radius: 12px; 
          text-align: center;
          max-width: 400px;
        ">
          <h2 style="color: green;">Compra realizada con éxito</h2>
          <p>Tu curso ya está disponible en la sección de Mis cursos, si la compra ha sido individual se encuentra
          en la sección de Comprado, en otro caso permanecerá En Cola esperando la confirmación de los amigos.</p>
          <button id="cerrarModal" style="
            margin-top: 1rem; 
            padding: 0.5rem 1rem;
            background: green;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
          ">Cerrar</button>
        </div>
      `;

      document.body.appendChild(modal);

      document.getElementById("cerrarModal").addEventListener("click", () => {
        modal.remove();
        // Opcional: limpiar el query param de la URL
        window.history.replaceState({}, document.title, "/mis_cursos");
      });
    }
  });

