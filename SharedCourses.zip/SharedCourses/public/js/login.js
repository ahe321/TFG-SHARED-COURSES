
// login.js

$(document).ready(() => {
    $("#iniciar-sesion-btn").on("click", iniciarSesion);
    mostrarMensajeSiProcede();
});

function iniciarSesion() {
    const correo = $('[name="correo"]').val();
    const contrasena = $('[name="contrasena"]').val();

    // Realizar la solicitud AJAX al servidor
    $.ajax({
        method: "POST",
        url: "/crear-sesion",
        contentType: "application/json",
        data: JSON.stringify({ correo, contrasena }),
        success: function (response) {
            window.location.href = response.redirectUrl;
        },
        error: function (error) {
            showAlertModal(error.responseJSON.title, error.responseJSON.message);
        }
    });
}

function mostrarMensajeSiProcede() {
    const error = window.locator.locals.error;
    if (!error)
        console.log('No hay error.');
    if (error) {
        // Mostrar mensaje de error
        showAlertModal(error.title, error.message);
        // Borrar el objeto de locals
        window.locator.locals.error = null;
    }
}

function mostrarMensajeSiProcede() {
    const errorCookie = $.cookie('error');
    if (errorCookie) {
        const error = JSON.parse(errorCookie);

        // Utilizando jQuery Cookie para eliminar la cookie
        $.removeCookie('error', { path: '/' });

        showAlertModal(error.title, error.message);
    }
}