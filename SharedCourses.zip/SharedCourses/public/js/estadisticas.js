$(document).ready(function () {
    // Obtener estadísticas generales
    $.ajax({
      url: '/obtener-estadisticas',
      method: 'GET',
      success: function (data) {
        $('#totalCursos').text(data.estadisticas.cursosTotales);
        $('#totalUsuarios').text(data.estadisticas.usuariosRegistrados);
        $('#valoracionPromedio').html(data.estadisticas.valoracionPromedio + ' <i class="fas fa-star"></i>');
        $('#totalCertificados').text(data.estadisticas.certificadosEmitidos);
      },
      error: function () {
        console.error('Error al obtener estadísticas.');
      }
    });
  
    // Obtener los cursos más populares
    $.ajax({
      url: '/obtener-cursos',
      method: 'GET',
      success: function (data) {
        const listaTop = $('#listaTop');
        listaTop.empty();
        
        // Ordenar los cursos por el número de inscritos de mayor a menor
        const cursosOrdenados = data.cursos.sort((a, b) => b.num_inscritos - a.num_inscritos);
  
        // Seleccionar solo los 5 primeros cursos
        const top5Cursos = cursosOrdenados.slice(0, 5);
  
        // Mostrar los 5 cursos más populares
        top5Cursos.forEach((curso, index) => {
          const item = `
            <li class="list-group-item d-flex justify-content-between align-items-center">
              ${index + 1}. ${curso.name}
              <span class="badge bg-primary rounded-pill">${curso.num_inscritos} inscritos</span>
            </li>
          `;
          listaTop.append(item);
        });
      },
      error: function () {
        console.error('Error al obtener los cursos más populares.');
      }
    });
  });
  