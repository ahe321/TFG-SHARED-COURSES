const idCurso = getCourseIdFromUrl();

function getCourseIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('idCurso');
}

function getCourseNameFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('nombreCurso');
}

const nombreCurso = getCourseNameFromUrl();

$(document).ready(function() {
    loadLessons();  // Solo carga las lecciones
    loadCompletedLessons();  // Filtra completadas según idCurso
});



let completedLessons = [];
let currentLesson = null;
let currentLessonName = null;
let currentTestQuestions = [];
let userAnswers = [];
let tests = [];

// Cargar todas las lecciones y filtrarlas por idCurso
// Reemplaza toda la función loadLessons con esta versión actualizada:
function loadLessons() {
    $.ajax({
        url: '/get-lecciones',  // Ruta en el backend
        method: 'GET',
        success: function(data) {
            const lessonList = $('#lesson-list');
            lessonList.empty();
            let primeraLesson = null;

            data.forEach(lesson => {
                if (lesson.idCurso === Number(idCurso)) {
                    const li = $('<li>')
                        .addClass('list-group-item lesson-item text-light bg-dark')
                        .text(lesson.nombre)
                        .attr('data-lesson-id', lesson.id)
                        .on('click', () => loadLesson(lesson));

                    lessonList.append(li);

                    if (!primeraLesson) {
                        primeraLesson = lesson;
                        loadLesson(lesson);
                    }

                    // Obtener test desde el backend para cada lección
                    $.ajax({
                        url: '/obtener-test-por-leccion',
                        method: 'POST',
                        data: { idLeccion: lesson.id },
                        success: function(testData) {
                            if (Array.isArray(testData.test) && testData.test.length > 0) {
                                tests[lesson.id] = {
                                    questions: testData.test.map(pregunta => ({
                                        question: pregunta.question,
                                        options: [pregunta.option1, pregunta.option2, pregunta.option3],
                                        correct: pregunta.correct != null ? parseInt(pregunta.correct) : 0
                                    }))
                                };
                            }
                        },
                        error: function(err) {
                            console.error(`Error al obtener test de la lección ${lesson.id}:`, err);
                        }
                    });
                }
            });
        },
        error: function(error) {
            console.error('Error al cargar las lecciones:', error);
        }
    });
}


function loadLesson(lesson) {

    currentLesson = lesson.id;
    currentLessonName = lesson.nombre;
    document.getElementById("lesson-title").innerText = lesson.nombre;
    document.getElementById("video-source").src = lesson.ruta;
    document.getElementById("lesson-video").load();
    document.getElementById("lesson-video").style.display = "block";
    //const completeBtn = document.getElementById("complete-btn");
    //completeBtn.setAttribute("data-lesson", lesson.id);

    // Verificar si la lección ya está completada
    //completeBtn.disabled = completedLessons.some(completed => completed.idLeccion === lesson.id);
    //document.getElementById("complete-btn").disabled = false;
    //document.getElementById("complete-btn").setAttribute("data-lesson", lesson.id);
    document.getElementById("test-btn").disabled = false;
}

// Cargar las lecciones completadas de un curso con AJAX
function loadCompletedLessons() {

    $.ajax({
        url: '/get-lecciones-completadas',
        method: 'GET',
        data: null,
        success: function(data) {
            // Filtrar las lecciones completadas por idCurso
            completedLessons = data.filter(completedLesson => completedLesson.idCurso === Number(idCurso));
            // Marcar las lecciones completadas
            completedLessons.forEach(completedLesson => {
                const lessonItem = $(`[data-lesson-id='${completedLesson.idLeccion}']`);
                if (lessonItem.length) {
                    lessonItem.addClass('completed');
                    //$('#complete-btn').prop('disabled', true);
                }
            });

            if (currentLesson && completedLessons.some(completed => completed.idLeccion === currentLesson)) {
                //$('#complete-btn').prop('disabled', true);
            }
            updateProgress();
        },
        error: function(error) {
            console.error('Error al cargar las lecciones completadas:', error);
        }
    });
}

// Marcar una lección como completada con AJAX
function markCompleted() {
    const lessonId = $('#complete-btn').attr('data-lesson');
    if (!completedLessons.some(completed => completed.idLeccion === lessonId)) {
        completedLessons.push({ idLeccion: Number(lessonId), idCurso: Number(idCurso) });
        $(`[data-lesson-id='${lessonId}']`).addClass('completed');
        $('#complete-btn').prop('disabled', true); 
        updateProgress();
    }

    $.ajax({
        url: '/mark-lesson-completed',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ idLeccion: lessonId, idCurso: idCurso }),
        success: function(data) {
            console.log('Lección marcada como completada:', data);
            $('#complete-btn').prop('disabled', true);
        },
        error: function(error) {
            console.error('Error al marcar la lección como completada:', error);
        }
    });
}

// Actualizar la barra de progreso
function updateProgress() {
    const totalLessons = $('#lesson-list .lesson-item').length;
    const progress = (completedLessons.length / totalLessons) * 100;
    
    $('#progress-bar').css('width', `${progress}%`).attr('aria-valuenow', progress);

    if (progress === 100) {
        showCongratsModal();
    }
}

let certificado;

function showCongratsModal() {
    // Primero obtienes el certificado de forma asincrónica y luego procedes
    obtenerCertificado().then(() => {
        console.log(certificado);
        if (!certificado) {
            const modal = new bootstrap.Modal($('#congratsModal').get(0));
            modal.show();
            insertCertificate();
        }
    }).catch((error) => {
        console.error("Error al obtener el certificado: ", error);
    });
}

function obtenerCertificado() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '/obtener-certificado',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                idCurso: idCurso
            }),
            success: function(response) {
                if (response.certificado && response.certificado.length > 0) {
                    certificado = response.certificado[0];  // Si hay certificado, usar el primero
                    console.log("Ya existe un certificado");
                    resolve();
                } else {
                    certificado = null;
                    console.log("No existe un certificado para este curso");
                    resolve();  // Resuelve aunque no haya certificado
                }
            },
            error: function(error) {
                certificado = null;
                console.error("Error al obtener el certificado");
                reject(error);
            }
        });
    });
}


function insertCertificate() {
    const fechaEmision = getCurrentDate();

    $.ajax({
        url: '/insert-certificado',  // Asegúrate de tener esta ruta en el backend
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            idCurso: idCurso,
            nombreCurso: nombreCurso,
            fechaEmision: fechaEmision
        }),
        success: function(response) {
            console.log('Certificado generado:', response);
            // Aquí puedes mostrar un enlace al certificado si es necesario
            //$('#certificado-link').html(`<a href="/certificado/${response.id}" target="_blank">Ver Certificado</a>`);
            //$('#certificado-link').html(`<a href="certificados" target="_blank">Ver Certificado</a>`);
        },
        error: function(error) {
            console.error('Error al generar el certificado:', error);
        }
    });
}


// Enviar las respuestas del test
function submitTest() {
    let score = 0;
    let feedback = "<h5>Resultados del Test</h5>";

    currentTestQuestions.forEach((q, index) => {
        const userAnswer = userAnswers[index];
        const correctAnswer = q.correct;
        if (userAnswer === correctAnswer) {
            score++;
            feedback += `<p>Pregunta ${index + 1}: Correcta. Respuesta correcta: ${q.options[correctAnswer]}</p>`;
        } else {
            feedback += `<p>Pregunta ${index + 1}: Incorrecta. Respuesta correcta: ${q.options[correctAnswer]}</p>`;
        }
    });

    feedback += `<p><strong>Puntaje final: ${score} de ${currentTestQuestions.length}</strong></p>`;
    $('#test-content').html(feedback);
    $('#finishBtn').hide();

    // Si supera el test, marcar como completada
    if (score > currentTestQuestions.length / 2) {
        if (!completedLessons.some(cl => cl.idLeccion === currentLesson)) {
            completedLessons.push({ idLeccion: currentLesson, idCurso: Number(idCurso) });
            $(`[data-lesson-id='${currentLesson}']`).addClass('completed');
            updateProgress();

            // Mostrar mensaje visual
            $('#test-content').prepend(`
                <div class="alert alert-success" role="alert">
                    ¡Felicidades! Has aprobado el test y la lección se ha marcado como completada.
                </div>
            `);

            // Guardar en el backend
            $.ajax({
                url: '/mark-lesson-completed',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ idLeccion: currentLesson, idCurso: idCurso }),
                success: function(data) {
                    console.log('Lección marcada como completada automáticamente:', data);
                },
                error: function(error) {
                    console.error('Error al marcar la lección como completada:', error);
                }
            });
        }
    } else {
        $('#test-content').prepend(`
            <div class="alert alert-warning" role="alert">
                No alcanzaste la puntuación necesaria para completar la lección. Inténtalo de nuevo.
            </div>
        `);
    }
}


// Cargar las preguntas del test cuando se abre el modal
$('#test-btn').on('click', function () {
    $('#finishBtn').show();
    currentTestQuestions = tests[currentLesson].questions;
    let testHtml = "<h5>Responde las siguientes preguntas:</h5>";

    currentTestQuestions.forEach((q, index) => {
        testHtml += `
            <div>
                <p><strong>${q.question}</strong></p>
                ${q.options.map((opt, i) => `<label><input type="radio" name="q${index}" value="${i}"> ${opt}</label><br>`).join("")}
            </div>
        `;
    });

    testHtml += "<br>";
    $('#test-content').html(testHtml);
});

// Guardar las respuestas del usuario
$('#test-content').on('change', 'input[type="radio"]', function (event) {
    const questionIndex = parseInt(event.target.name.replace('q', ''));
    userAnswers[questionIndex] = parseInt(event.target.value);
});


function goHome() {
    window.location.href = "/mis_cursos";
}

function getCurrentDate() {
    const today = new Date();
    const day = today.getUTCDate().toString().padStart(2, "0");
    const month = (today.getUTCMonth() + 1).toString().padStart(2, "0");
    const year = today.getUTCFullYear().toString().padStart(4, "0");
    return `${day}/${month}/${year}`;
}

$(document).ready(function() {
    $('#forum-btn').on('click', function() {
        const idCurso = getCourseIdFromUrl();
        if (idCurso) {
            //window.location.href = `/foro?idCurso=${idCurso}`;
            window.open(`/foro?idCurso=${idCurso}&nombreLeccion=${encodeURIComponent(currentLessonName)}`, '_blank');
        } else {
            console.error('No se encontró idCurso en la URL.');
        }
    });
});
