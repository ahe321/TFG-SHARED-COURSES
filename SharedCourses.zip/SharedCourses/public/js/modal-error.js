
// modal-error.js

// Mostrar un modal de Bootstrap con el mensaje de error
function showAlertModal(title, message) {
    const modalHtml = `
        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        ${message}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Agregar el modal al cuerpo del documento
    $(document.body).append(modalHtml);

    // Mostrar el modal
    $('#errorModal').modal('show');
    
    // Eliminar el modal del DOM después de cerrarlo
    $('#errorModal').on('hidden.bs.modal', function () {
        $(this).remove();
    });
}