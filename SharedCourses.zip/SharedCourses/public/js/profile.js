$(document).ready(function() {
    $('#loadingSpinner').hide();
    // Realizar la petición AJAX al servidor para obtener los datos del perfil
    $.ajax({
        url: 'obtener-perfil',  // URL del endpoint que devuelve los datos del perfil
        method: 'POST',
        success: function(response) {
            
            $('#name').text(response.usuario.nombre);  // Nombre
            $('#email').text(response.usuario.correo);  // Correo electrónico
            $('#lastName').text(response.usuario.apellido1);  // Primer apellido
            $('#secondLastName').text(response.usuario.apellido2);  // Segundo apellido
            if(response.usuario.foto != null)
                $('#imagenPerfil').append(`<img src="${response.usuario.foto}" class="img-thumbnail avatar sm rounded-pill me-3 flex-shrink-0" alt="Foto Perfil">`); //Foto
            else
                $('#imagenPerfil').append(`<img src="../img/defecto/usuario.png" class="img-thumbnail avatar sm rounded-pill me-3 flex-shrink-0" alt="Foto Perfil">`); //Foto

            let preferencias = response.usuario.preferencias || "Ninguna";
            $('#preferences').text(preferencias.charAt(0).toUpperCase() + preferencias.slice(1));
            $('#inputPreferences').val(preferencias.toLowerCase());
        },
        error: function(error) {
            // Si hay un error en la solicitud AJAX
            showAlertModal("Error", "Hubo un error al intentar cargar los datos");
        }
    });

        // Listener del botón de 'guardar foto'
        $("#guardarFoto").on('click', enviarConfiguracion);

        // Listener de campo de 'email'
        $("#inputPassword").on('input change', actualizarBotonEnviar);
    
        // Listener del botón de 'guardar email'
        $("#guardarContrasena").on('click', enviarConfiguracion);

        // Limpiar al cerrar
        $('#passwordModal').on('hidden.bs.modal', function (e) {
            $(this)
              .find("input,textarea,select")
                 .val('')
                 .end()
              .find("input[type=checkbox], input[type=radio]")
                 .prop("checked", "")
                 .end();
          })

        // Listener de campo de 'email'
        $("#inputName").on('input change', actualizarBotonEnviar);
    
        // Listener del botón de 'guardar email'
        $("#guardarNombre").on('click', enviarConfiguracion);

        // Limpiar al cerrar
        $('#nameModal').on('hidden.bs.modal', function (e) {
            $(this)
              .find("input,textarea,select")
                 .val('')
                 .end()
              .find("input[type=checkbox], input[type=radio]")
                 .prop("checked", "")
                 .end();
          })

        // Listener de campo de 'email'
        $("#inputLastName").on('input change', actualizarBotonEnviar);
    
        // Listener del botón de 'guardar email'
        $("#guardarPrimerApellido").on('click', enviarConfiguracion);

        // Limpiar al cerrar
        $('#lastNameModal').on('hidden.bs.modal', function (e) {
            $(this)
              .find("input,textarea,select")
                 .val('')
                 .end()
              .find("input[type=checkbox], input[type=radio]")
                 .prop("checked", "")
                 .end();
          })

        // Listener de campo de 'email'
        $("#inputSecondLastName").on('input change', actualizarBotonEnviar);
    
        // Listener del botón de 'guardar email'
        $("#guardarSegundoApellido").on('click', enviarConfiguracion);

        // Limpiar al cerrar
        $('#secondLastNameModal').on('hidden.bs.modal', function (e) {
            $(this)
              .find("input,textarea,select")
                 .val('')
                 .end()
              .find("input[type=checkbox], input[type=radio]")
                 .prop("checked", "")
                 .end();
          })

        // Listener del botón de 'guardar preferencias'
        $("#guardarPreferencias").on('click', enviarConfiguracion);
    
        // Actualizar al cargar
        actualizarBotonEnviar()
    
        function actualizarBotonEnviar() {
            const name = $("#inputName").val();
            const lastName = $("#inputLastName").val();
            const secondLastName = $("#inputSecondLastName").val();
            const password = $("#inputPassword").val();

            // Verifica si el valor es válido
            if (name !== '' && isValidAlphabeticString(name)) {
                // Habilitar el botón
                $('#guardarNombre').prop('disabled', false);
            } else {
                // Deshabilitar el botón
                $('#guardarNombre').prop('disabled', true);
            }

            // Verifica si el valor es válido
            if (lastName !== '' && isValidAlphabeticString(lastName)) {
                // Habilitar el botón
                $('#guardarPrimerApellido').prop('disabled', false);
            } else {
                // Deshabilitar el botón
                $('#guardarPrimerApellido').prop('disabled', true);
            }

            // Verifica si el valor es válido
            if (secondLastName !== '' && isValidAlphabeticString(secondLastName)) {
                // Habilitar el botón
                $('#guardarSegundoApellido').prop('disabled', false);
            } else {
                // Deshabilitar el botón
                $('#guardarSegundoApellido').prop('disabled', true);
            }

            // Verifica si el valor es válido
            if (password !== '' && password.length >= 6) {
                // Habilitar el botón
                $('#guardarContrasena').prop('disabled', false);
            } else {
                // Deshabilitar el botón
                $('#guardarContrasena').prop('disabled', true);
            }
        }
    
        function enviarConfiguracion() {
            // Obtener el elemento de entrada de archivo
            const name = $("#inputName").val();
            const lastName = $("#inputLastName").val();
            const secondLastName = $("#inputSecondLastName").val();
            const password = $("#inputPassword").val();
            const preferences = $("#inputPreferences").val();
    
            // Crear un objeto FormData para enviar el fichero
            const formData = new FormData();
            formData.append('nombre', name);
            formData.append('apellido1', lastName);
            formData.append('apellido2', secondLastName);
            formData.append('contrasena', password);
            formData.append("preferencias", preferences);
            // Obtener el archivo de la entrada de imagen
            const profilePicFile = $("#inputFoto")[0].files[0];
            formData.append("file", profilePicFile);
    
            // Solicitud AJAX
            $.ajax({
                url: "/cambiar-perfil",
                method: "POST",
                data: formData,
                contentType: false, // No establecer contentType para FormData
                processData: false, // No procesar datos para FormData
                success: function (response) {
                    showAlertModal(response.title, response.message);
                },
                error: function (error) {
                    if(error.title !== undefined)
                        showAlertModal(error.responseJSON.title, error.responseJSON.message);
                    else
                        showAlertModal("Error", "Hubo un error al intentar actualizar el perfil");
                },
            });
        }

        // Listener del botón de confirmación de darse de baja
    $("#confirmUnsubscribe").on("click", function() {
        $.ajax({
            url: "/darse-de-baja",  // Endpoint que maneja la baja del usuario
            method: "POST",
            success: function(response) {
                // Mostrar mensaje de éxito
                showAlertModal("Usuario dado de baja", response.message || "Tu cuenta ha sido eliminada.");

                // Cerrar modal
                $("#unsubscribeModal").modal('hide');

                // Redirigir al inicio o logout
                setTimeout(function() {
                    window.location.href = "/"; // Cambiar según la ruta de logout/inicio
                }, 1500);
            },
            error: function(error) {
                showAlertModal("Error", error.responseJSON?.message || "No se pudo dar de baja el usuario.");
            }
        });
});

});

function showAlertModal(title, message) {
    const modalHtml = `
        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        ${message}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Agregar el modal al cuerpo del documento
    $(document.body).append(modalHtml);

    // Mostrar el modal
    $('#errorModal').modal('show');
    
    // Eliminar el modal del DOM después de cerrarlo
    $('#errorModal').on('hidden.bs.modal', function () {
        $(this).remove();
    });
}

function isValidAlphabeticString(value) {
    // Expresión regular para validar que la cadena solo contenga letras y no haya espacios
    const alphabeticStringRegex = /^[A-Za-z]+$/;
    return alphabeticStringRegex.test(value);
    }
    
