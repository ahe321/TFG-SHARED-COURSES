let certificadosUsuario = [];
let nombreUsuario;
let apellido1;
let apellido2;

$(document).ready(function () {
    // Función para obtener las órdenes del usuario
    function obtenerOrdenes() {
        $.ajax({
            url: "/ordenes-por-correo",
            method: "GET",
            dataType: "json",
            success: function (data) {
                const sinConfirmar = data.ordenes.filter(orden => orden.estado === 'sin_confirmar');
                const enCola = data.ordenes.filter(orden => orden.estado === 'en_cola');
                const comprado = data.ordenes.filter(orden => orden.estado === 'comprado');

                cargarCursos(sinConfirmar, "cursosSinConfirmar", [
                    { texto: "Confirmar", color: "primary", accion: "confirmar" },
                    //{ texto: "Cancelar", color: "danger", accion: "cancelar" },
                    { texto: "Detalles", color: "info", accion: "detalles" }
                ]);
                cargarCursos(enCola, "cursosEnCola");
                cargarCursos(comprado, "cursosComprados", [
                    { texto: "Ir al curso", color: "success", accion: "ir-al-curso" }
                ]);
            },
            error: function (xhr, status, error) {
                console.error("Error al obtener órdenes:", error);
                $("#sinConfirmar").append(`<div class="col-12 text-center"><img src="../img/sin_confirmar2.png" alt="No hay cursos sin confirmar" class="img-fluid" style="max-width: 500px;" /></div>`);
                $("#enCola").append(`<div class="col-12 text-center"><img src="../img/sin_cola.png" alt="No hay cursos en cola" class="img-fluid" style="max-width: 500px;" /></div>`);
                $("#comprado").append(`<div class="col-12 text-center"><img src="../img/sin_comprar.png" alt="No hay cursos comprados" class="img-fluid" style="max-width: 500px;" /></div>`);
                showAlertModal("Aviso", "No dispones de ningun curso");
            }
        });
    }

    // Función para cargar los cursos
    function cargarCursos(ordenes, contenedorId, botones = []) {
        const contenedor = $("#" + contenedorId);
        contenedor.empty();

        // Verificar si no hay cursos en la lista
        if (ordenes.length === 0) {
            let imagen;
            if (contenedorId === "cursosSinConfirmar") {
                imagen = `<div class="col-12 text-center"><img src="../img/sin_confirmar2.png" alt="No hay cursos sin confirmar" class="img-fluid" style="max-width: 500px;" /></div>`;
            } else if (contenedorId === "cursosEnCola") {
                imagen = `<div class="col-12 text-center"><img src="../img/sin_cola.png" alt="No hay cursos en cola" class="img-fluid" style="max-width: 500px;" /></div>`;
            } else if (contenedorId === "cursosComprados") {
                imagen = `<div class="col-12 text-center"><img src="../img/sin_comprar.png" alt="No hay cursos comprados" class="img-fluid" style="max-width: 500px;" /></div>`;
            }
            contenedor.append(imagen);
            return;
        }

        const idsCursos = ordenes.map(orden => orden.id_curso);
        obtenerCursosPorIds(idsCursos, contenedor, botones, ordenes);
    }

    // Función para obtener los cursos relacionados
    function obtenerCursosPorId(idsCursos, contenedor, botones, ordenes) {
        $.ajax({
            url: "/obtener-cursos",
            method: "GET",
            dataType: "json",
            success: function (data) {
                const cursosRelacionados = data.cursos.filter(curso => idsCursos.includes(curso.id));

                cursosRelacionados.forEach(curso => {
                    console.log("Cargando curso:", curso);
                    const orden = ordenes.find(o => o.id_curso === curso.id);
                    const card = $(`
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">${curso.name}</h5>
                                    <p class="card-text">${curso.description}</p>
                                    ${botones.map(btn => `
                                        <button class="btn btn-${btn.color}" 
                                            data-accion="${btn.accion}" 
                                            data-id="${curso.id}" 
                                            data-correo="${orden.correo_usuario}">
                                            ${btn.texto}
                                        </button>
                                    `).join(" ")}
                                </div>
                            </div>
                        </div>
                    `);
                    contenedor.append(card);
                });

                // Agregar eventos a los botones
                botones.forEach(btn => {
                    $(`button[data-accion="${btn.accion}"]`).each(function () {
                        $(this).click(function () {
                            const idCurso = $(this).data("id");
                            const correoUsuario = $(this).data("correo");
                            const cursoSeleccionado = cursosRelacionados.find(c => c.id === idCurso);
                            
                            if (!cursoSeleccionado) {
                                console.error("No se encontró el curso con ID:", idCurso);
                                return;
                            }
                            
                            if (btn.accion === "confirmar") {
                                cambiarEstado(cursoSeleccionado);
                            } else if (btn.accion === "cancelar") {
                                borrarOrden(idCurso);
                            } else if (btn.accion === "detalles") {
                                mostrarDetallesModal(cursoSeleccionado);
                            } else if (btn.accion === "ir-al-curso") {
                                window.location.href = `/lecciones?idCurso=${idCurso}&nombreCurso=${encodeURIComponent(cursoSeleccionado.name)}`;
                            }
                        });
                    });
                });
            },
            error: function (xhr, status, error) {
                console.error("Error al obtener los cursos:", error);
                alert("Hubo un error al obtener los cursos.");
            }
        });
    }

    function obtenerCursosPorIds(idsCursos, contenedor, botones, ordenes) {
        $.ajax({
            url: "/obtener-cursos",
            method: "GET",
            dataType: "json",
            success: function (data) {
                const cursosRelacionados = data.cursos.filter(curso => idsCursos.includes(curso.id));
    
                cursosRelacionados.forEach(curso => {
                    console.log("Cargando curso:", curso);
                    const orden = ordenes.find(o => o.id_curso === curso.id);
                    const tieneCertificado = certificadosUsuario.some(cert => cert.idCurso === curso.id);
    
                    const card = $(`
                        <div class="col-md-4 mb-3">
                            <div class="card position-relative">
                                ${tieneCertificado ? `
                                    <span class="fa fa-trophy badge bg-success position-absolute top-0 end-0 m-2">
                                        Completado
                                    </span>
                                ` : ""}
                                <div class="card-body">
                                    <h5 class="card-title">${curso.name}</h5>
                                    <p class="card-text">${curso.description}</p>

                                    ${botones.map(btn => `
                                        <button class="btn btn-${btn.color}" 
                                            data-accion="${btn.accion}" 
                                            data-id="${curso.id}" 
                                            data-correo="${orden.correo_usuario}">
                                            ${btn.texto}
                                        </button>
                                    `).join(" ")}
    
                                    <!-- Botón Ver Certificado si el curso está completado -->
                                    ${tieneCertificado ? `
                                        <button class="btn btn-warning ms-2 btn-ver-certificado" 
                                            data-id="${curso.id}"
                                            data-nombre-usuario="${orden.nombre_usuario}" 
                                            data-nombre-curso="${curso.name}">
                                            Ver Certificado
                                        </button>
                                        <button class="btn btn-outline-primary ms-2 btn-valorar-curso" 
                                            data-id="${curso.id}">
                                            ⭐
                                        </button>
                                    ` : ""}
                                </div>
                            </div>
                        </div>
                    `);
                    contenedor.append(card);
                });

                // Agregar eventos a los botones
                botones.forEach(btn => {
                    $(`button[data-accion="${btn.accion}"]`).each(function () {
                        $(this).click(function () {
                            const idCurso = $(this).data("id");
                            const correoUsuario = $(this).data("correo");
                            const cursoSeleccionado = cursosRelacionados.find(c => c.id === idCurso);
                            const ordenSeleccionada = ordenes.find(o => o.id_curso === idCurso);
                            
                            if (!cursoSeleccionado) {
                                console.error("No se encontró el curso con ID:", idCurso);
                                return;
                            }
                            
                            if (btn.accion === "confirmar") {
                                cambiarEstado(cursoSeleccionado, ordenSeleccionada);
                            } else if (btn.accion === "cancelar") {
                                borrarOrden(idCurso);
                            } else if (btn.accion === "detalles") {
                                mostrarDetallesModal(cursoSeleccionado);
                            }
                        });
                    });
                });
    
                // Evento para "Ir al curso"
                $(`button[data-accion="ir-al-curso"]`).each(function () {
                    $(this).click(function () {
                        const idCurso = $(this).data("id");
                        const cursoSeleccionado = cursosRelacionados.find(c => c.id === idCurso);
    
                        if (!cursoSeleccionado) {
                            console.error("No se encontró el curso con ID:", idCurso);
                            return;
                        }
    
                        window.location.href = `/lecciones?idCurso=${idCurso}&nombreCurso=${encodeURIComponent(cursoSeleccionado.name)}`;
                    });
                });
    
                // Evento para "Ver Certificado"
                $(".btn-ver-certificado").click(function () {
                    const nombreCurso = $(this).data("nombre-curso");
                    const idCurso = $(this).data("id");
                        
                    const certificado = certificadosUsuario.find(cert => cert.idCurso === idCurso);


                    if (!certificado) {
                        console.error("No se encontró un certificado para este curso.");
                        return;
                    }
                
                    mostrarCertificado(nombreUsuario, apellido1, apellido2, nombreCurso, certificado.fechaEmision);
                });
            },
            error: function (xhr, status, error) {
                console.error("Error al obtener los cursos:", error);
                alert("Hubo un error al obtener los cursos.");
            }
        });
    }
    
    

    // Función para mostrar los detalles del curso en el modal
    function mostrarDetallesModal(curso) {
        console.log("Mostrando detalles del curso:", curso);
        
        $("#modal-course-name").text(curso.name);
        $("#modal-course-description").text(curso.long_description);
        $("#modal-course-duration").text(`Duración: ${curso.duration}`);
        $("#modal-course-level").text(`Nivel: ${curso.level}`);
        $("#modal-course-precio").text(`Precio: €${curso.precio}`);
        $("#modal-course-image").attr("src", curso.image);

        let modalElement = document.getElementById("courseModal");
        let modal = new bootstrap.Modal(modalElement);
        modal.show();
    }

    // Función para cambiar el estado de la orden
    function cambiarEstado(curso, orden) {
        $.ajax({
            url: "cambiar-estado",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify({ curso, orden }),
            success: function (response) {
                window.location.href = response.checkoutUrl;
                showAlertModal("Exito", "Has confirmado la compra del curso");
                obtenerOrdenes();
            },
            error: function (xhr, status, error) {
                showAlertModal("Error", "Ha ocurrido un error al intentar confirmar la compra del curso");
            }
        });
    }

    // Función para borrar la orden
    function borrarOrden(id_curso) {
        $.ajax({
            url: "/borrar-orden",
            method: "DELETE",
            contentType: "application/json",
            data: JSON.stringify({ id_curso }),
            success: function (data) {
                showAlertModal("Exito", "Has cancelado la compra del curso")
                obtenerOrdenes();
            },
            error: function (xhr, status, error) {
                showAlertModal("Error", "Error al cancelar la compra del curso");
            }
        });
    }

    // Cargar las órdenes al inicio
    obtenerCertificados();
    obtenerOrdenes();
});

function obtenerCertificados() {
    $.ajax({
        url: "/get-certificados-usuario",
        method: "GET",
        dataType: "json",
        success: function (data) {
            certificadosUsuario = data.certificados; // Guardamos los certificados obtenidos
            nombreUsuario = data.nombreUsuario.toUpperCase();
            apellido1 = data.apellido1.toUpperCase();
            apellido2 = data.apellido2.toUpperCase();
            console.log("Certificados obtenidos:", certificadosUsuario);
        },
        error: function (xhr, status, error) {
            console.error("Error al obtener certificados:", error);
        }
    });
}

function showAlertModal(title, message) {
    // Mostrar un modal de Bootstrap con el mensaje de error
    const modalHtml = `
        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        ${message}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Agregar el modal al cuerpo del documento
    $(document.body).append(modalHtml);
    
    // Mostrar el modal
    $('#errorModal').modal('show');
    
    // Eliminar el modal del DOM después de cerrarlo
    $('#errorModal').on('hidden.bs.modal', function () {
        $(this).remove();
    });
    }

    function mostrarCertificadoModal(nombreUsuario, apellido1, apellido2, nombreCurso, fechaActual) {


        // Convertirla a un objeto Date
        const fecha = new Date(fechaActual);

        // Formatear la fecha a un formato más legible (día-mes-año)
        const fechaFormateada = fecha.toLocaleDateString('es-ES'); // 'es-ES' para formato español
    
        const certificadoHtml = `
            <div class="certificate" style="max-width: 800px; background: white; padding: 40px; border: 10px solid #b8860b; text-align: center; margin: 20px auto; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                <h1 style="font-size: 2.5rem; color: #b8860b;">Certificado de Finalización</h1>
                <p style="font-size: 1.2rem;">Otorgado a:</p>
                <h2>${nombreUsuario}" "${apellido1}" "${apellido2}</h2>
                <p style="font-size: 1.2rem;">Por completar exitosamente el curso:</p>
                <h3>${nombreCurso}</h3>
                <p style="font-size: 1.2rem;">Fecha de finalización: ${fechaFormateada}</p>
                <div class="signature" style="margin-top: 40px; text-align: right; font-size: 1rem; font-weight: bold;">
                    <img src="../public/img/shared_courses_signature.png" alt="Firma de SharedCourse" style="max-width: 200px; display: block; margin: 0 auto;">
                </div>
            </div>
        `;
    
        $("#certificadoContenido").html(certificadoHtml);
    
        let modal = new bootstrap.Modal(document.getElementById("certificadoModal"));
        modal.show();
    }
    
    function mostrarCertificado(nombreUsuario, apellido1, apellido2, nombreCurso, fechaActual) {
        // Convertir la fecha
        const fecha = new Date(fechaActual);
        const fechaFormateada = fecha.toLocaleDateString('es-ES');
    
        // Redirigir a la ruta '/certificado' con los parámetros en la URL
        const url = `/certificados?nombreUsuario=${encodeURIComponent(nombreUsuario)}&apellido1=${encodeURIComponent(apellido1)}&apellido2=${encodeURIComponent(apellido2)}&nombreCurso=${encodeURIComponent(nombreCurso)}&fecha=${encodeURIComponent(fechaFormateada)}`;
        //window.location.href = url;
        window.open(url, '_blank');
    }


    $(document).on("click", ".btn-valorar-curso", function () {
        const idCurso = $(this).data("id");
        $("#inputIdCursoValorar").val(idCurso);
        $("#inputRating").val("5"); // valor por defecto
        new bootstrap.Modal(document.getElementById("modalValorarCurso")).show();
    });
    
    $("#btnEnviarRating").click(function () {
        const idCurso = $("#inputIdCursoValorar").val();
        const rating = parseInt($("#inputRating").val());
        const idUsuario = 1;
        console.log(Number(idCurso));
        console.log(rating);
        console.log(idUsuario);
        if (!idCurso || isNaN(rating)) {
            showAlertModal("Error", "Faltan datos para enviar la valoración.");
            return;
        }
    
        $.ajax({
            url: "/insertar-rating",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify({
                idUsuario: idUsuario,
                idCurso: Number(idCurso),
                rating: rating
            }),
            success: function () {
                $("#modalValorarCurso").modal("hide");
                showAlertModal("Gracias", "¡Tu valoración ha sido registrada!");
            },
            error: function () {
                showAlertModal("Error", "No se pudo guardar la valoración. Inténtalo de nuevo.");
            }
        });
    });
    
    
    